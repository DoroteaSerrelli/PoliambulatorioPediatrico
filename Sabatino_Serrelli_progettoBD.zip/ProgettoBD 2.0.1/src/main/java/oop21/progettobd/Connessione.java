package oop21.progettobd;
import java.sql.*;
import java.io.*;
public class Connessione {
    public static void main(String args[]) throws Exception { 
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/poliambulatoriopediatrico";
            Connection con = DriverManager.getConnection(url, "root", "sabata");
        
            System.out.println("Connessione OK \n");
            MyFrame myframe= new MyFrame(con);
            
        } catch (ClassNotFoundException e) {
            System.out.println("DB driver not found \n");
            System.out.println(e);
        } catch (Exception e) {
            System.out.println("Connessione Fallita \n");
            System.out.println(e);
        }
        // con.close();
        
        
    }
}    
        /*
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/poliambulatoriopediatrico";
            Connection con = DriverManager.getConnection(url, "root", "sabata");
            
         // Step 2: Construct a 'Statement' object called 'stmt' inside the Connection created
        Statement stmt = con.createStatement();
        ResultSet rs= stmt.executeQuery("SELECT *FROM Specialista INNER JOIN PersonaleDellaStruttura ON NumeroTesserinoSp = NumeroTesserino;");
        while(rs.next()){
            int numTess= rs.getInt("NumeroTesserinoSp");
            String spec= rs.getString("Specializzazione");
            int anniser= rs.getInt("AnniServizio");
            String email= rs.getString("Email");
            String tel= rs.getString("TelefonoSpecialista");
            int codiceam= rs.getInt("CodiceAmbulatorio");
            System.out.println("numTess"+numTess+" specializzazione: "+spec);
            
        } 
            System.out.println("Connessione OK \n");
            con.close();
        } catch (ClassNotFoundException e) {
            System.out.println("DB driver not found \n");
            System.out.println(e);
        } catch (Exception e) {
            System.out.println("Connessione Fallita \n");
            System.out.println(e);
        }
        /*
        NumeroTesserinoSp int NOT NULL,
Specializzazione varchar(50) NOT NULL,
AnniServizio smallint NOT NULL,
Email varchar(64) NOT NULL,
CHECK(Email LIKE '%.%@poliambulatoriopediatrico.it'),
TelefonoSpecialista char(16) NOT NULL,
CHECK(TelefonoSpecialista LIKE '+39 ___ ___ ____'),
CodiceAmbulatorio smallint NOT NULL,



    } // end main
} // end Connessione

*/
