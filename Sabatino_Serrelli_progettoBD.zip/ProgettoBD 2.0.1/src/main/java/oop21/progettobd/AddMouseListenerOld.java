package oop21.progettobd;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JOptionPane;
class AddMouseListenerOld implements ActionListener{           
    JPanel p,showP;
    Connection con;         
        public void getStuff(JPanel p, Connection con, JPanel showP){
            this.p= p;
            this.con = con;
            this.showP= showP;
        }

    @Override
    public void actionPerformed(ActionEvent ae) {
       try{ 
            String s= ae.getActionCommand();
            if(s.compareTo("Query 2")==0){
              String something="";
              something= JOptionPane.showInputDialog("Inserire malattia cercata", something);
              System.out.println(something);
              PreparedStatement pstmt;
              ResultSet rs;
                    pstmt = con.prepareStatement
                    ("SELECT Nome, Cognome FROM Paziente, Terapia WHERE Sesso = 'F' "
                    + "AND Paziente.CodiceFiscale = Terapia.CodiceFiscale AND Malattia =?"
                    );                  
                    pstmt.setString(1,something);  
                    
                    rs = pstmt.executeQuery();
                    JTextArea area= (JTextArea)this.showP.getComponent(0);
                    area.setText("");
                    String nome, cognome;
                    while(rs.next()){
                        nome=( rs.getString("Nome"));
                        cognome=(rs.getString("Cognome"));                        
                        area.append("Nome e cognome paziente: "+nome+" "+cognome+'\n');
                    } 
                rs.close();
            }
            if(s.compareTo("Query 3")==0){
                ResultSet rs;
                try (Statement stmt = con.createStatement()) {
                    rs = stmt.executeQuery("SELECT * FROM Collaboratore, PersonaleDellaStruttura WHERE Collaboratore.NumeroTesserinoCo = PersonaleDellaStruttura.NumeroTesserino;");
                    String tipoContr, spec, cognome,nome;
                    int numTess,numMacc,eta;
                    JTextArea area= (JTextArea)this.showP.getComponent(0);
                    area.setText("");
                    while(rs.next()){
                        numTess= rs.getInt("NumeroTesserinoCo");
                        numMacc=(rs.getInt("Numero_macchinari"));
                        spec= rs.getString("Specializzazione");
                        nome=(rs.getString("Nome"));
                        cognome=(rs.getString("Cognome"));
                        eta=(rs.getInt("Età"));
                        tipoContr=rs.getString("TipoContratto");
                        
                        area.append("Numero Tessera: "+"[ "+numTess+" ] "+
                                " Numero Macchinari: "+numMacc+'\n'+
                                " Specializzazione: "+spec+"  "+
                                        " Nome e Cognome: "+nome+" "
                                +cognome+" "+
                                        " Eta: "+eta+'\n'+
                                " Tipo Contratto: "+tipoContr+ '\n' );
                    }
                }
                rs.close();
            }
            if(s.compareTo("Query 1")==0){               
                ResultSet rs;
                try (Statement stmt = con.createStatement()) {
                    rs = stmt.executeQuery("SELECT *FROM Specialista INNER JOIN PersonaleDellaStruttura ON NumeroTesserinoSp = NumeroTesserino;");
                    int numTess,codiceam,anniserv;
                    String tel,spec,email;
                    JTextArea area= (JTextArea)this.showP.getComponent(0);
                    area.setText("");
                    while(rs.next()){
                        numTess=( rs.getInt("NumeroTesserinoSp"));
                        spec=( rs.getString("Specializzazione"));
                        anniserv=(rs.getInt("AnniServizio"));
                        email=(rs.getString("Email"));
                        tel=(rs.getString("TelefonoSpecialista"));
                        codiceam=(rs.getInt("CodiceAmbulatorio"));
                        
                        area.append("Numero Tessera: "+"[ "+numTess+" ] "+
                                "Specializzazione: "+spec+"  "+
                                        "AnniServizio: "+anniserv+'\n'+
                                "Email: "+email+'\n'+
                                "Telefono: "+tel+"  "+
                                        "CAmbulatorio: "+codiceam+'\n' );
                        
                    }
                }
                rs.close();
            }
            if(s.compareTo("Query 4")==0){
                ResultSet rs;
                try (Statement stmt = con.createStatement()) {
                    rs = stmt.executeQuery("SELECT Nome, Cognome, TelefonoSpecialista FROM PersonaleDellaStruttura, Specialista WHERE PersonaleDellaStruttura.NumeroTesserino = Specialista.NumeroTesserinoSp ORDER BY Specializzazione ASC;");
                    String nome,cognome,telefono;
                    JTextArea area= (JTextArea)this.showP.getComponent(0);
                    area.setText("");
                    while(rs.next()){
                        nome=( rs.getString("Nome"));
                        cognome=(rs.getString("Cognome"));
                        telefono=(rs.getString("TelefonoSpecialista"));
                        
                        area.append("Nome e cognome Specialista: "+nome+" "+
                                cognome+"  "+
                                        "Telefono: "+telefono+'\n'
                        );
                        
                    }
                }
                rs.close();
            }
            if(s.compareTo("Query 5")==0){
                ResultSet rs;
                try (Statement stmt = con.createStatement()) {
                    rs = stmt.executeQuery
                        ("SELECT DISTINCT Paziente.CodiceFiscale,DataInizio, DataFine, Malattia\n" +
                                "FROM PersonaleDellaStruttura, Specialista, Paziente, Terapia\n" +
                                "WHERE PersonaleDellaStruttura.nome = 'Giovanni' AND PersonaleDellaStruttura.cognome = 'Bianchi' \n" +
                                "AND Paziente.Nome = 'Mario' AND Paziente.Cognome = 'Rossi'\n" +
                                "AND Specializzazione = 'Pediatria'\n" +
                                "AND PersonaleDellaStruttura.NumeroTesserino = Specialista.NumeroTesserinoSp\n" +
                                "AND Terapia.CodiceFiscale = Paziente.CodiceFiscale\n" +
                                "AND Terapia.NumeroTesserinoSp = Specialista.NumeroTesserinoSp;"
                        );  
                        String dataInizio,dataFine,malattia,cf;
                        JTextArea area= (JTextArea)this.showP.getComponent(0);
                        area.setText("");
                        while(rs.next()){
                            cf= (rs.getString("CodiceFiscale"));
                            dataInizio=( rs.getString("DataInizio"));
                            dataFine=(rs.getString("DataFine"));
                            malattia=(rs.getString("Malattia"));
                            
                            area.append("Codice fiscale paziente: "+ cf+'\n'
                                    + "DataInizio e dataFine: "+dataInizio+" "+
                                    dataFine+"  "+
                                            "Malattia: "+malattia+'\n'
                            );
                            
                        }
                }
                rs.close();
            }
            if(s.compareTo("Query 6")==0){
                ResultSet rs;
                try (Statement stmt = con.createStatement()) {
                    rs = stmt.executeQuery
                        ///Dovuto eliminare Ecografia.CodiceFiscale AS Paziente
                        //perché nel while rs.next ---> rs.getString non trova il 
                        //codice fiscale
                        ("SELECT CodiceEcografia, NomeEcografia, Descrizione, CodiceFiscale\n" +
                                "FROM PersonaleDellaStruttura, Ecografia INNER JOIN Specialista \n" +
                                "ON Ecografia.NumeroTesserinoSp = Specialista.NumeroTesserinoSp\n" +
                                "WHERE PersonaleDellaStruttura.NumeroTesserino = Specialista.NumeroTesserinoSp \n" +
                                "AND Nome = 'Giuseppe'\n" +
                                "AND Cognome = 'Neri' AND Specializzazione = 'Cardiologia';"
                        );  String nomeEco,descrizione,cf;
                        int codEco;
                        JTextArea area= (JTextArea)this.showP.getComponent(0);
                        area.setText("");
                        while(rs.next()){
                            codEco= (rs.getInt("CodiceEcografia"));
                            nomeEco= (rs.getString("NomeEcografia"));
                            descrizione=( rs.getString("Descrizione"));
                            cf=(rs.getString("CodiceFiscale"));
                            
                            area.append("Codice ecografia e nome: "+"[ "+ codEco+" ] "
                                    +nomeEco+'\n'+
                                    "Codice fiscale paziente: "+cf+'\n'
                            );
                            if(descrizione.length()>60){
                                String sub_descr_other_side;
                                String sub_descr= descrizione.substring(0, 80);
                                String array[]= {"a","e","i","o","u"};
                                boolean itdoes_end_with_vocals=false;
                                for(int i=0;i<5;i++){
                                    if(sub_descr.endsWith(array[i])) itdoes_end_with_vocals=true;
                                }
                                if(itdoes_end_with_vocals==false){
                                    sub_descr= descrizione.substring(0, 81);
                                    sub_descr_other_side= descrizione.substring(81,descrizione.length());
                                }
                                else
                                    sub_descr_other_side= descrizione.substring(80,descrizione.length());
                                
                                area.append(
                                        "Descrizione:"+'\n'+sub_descr+'\n'
                                                +sub_descr_other_side+'\n'
                                );
                                
                            }
                            else {
                                area.append(
                                        "Descrizione:"+'\n'+descrizione+'\n'
                                );
                            }
                        }
                        
                }
                rs.close();
                
            }
            
            if(s.compareTo("Query 7")==0){
                ResultSet rs;
                try (Statement stmt = con.createStatement()) {
                    rs = stmt.executeQuery
                        ("SELECT Ambulatorio.CodiceAmbulatorio, NumeroSerie, DataInstallazione, Modello, Fornitore, Descrizione\n" +
                                "FROM Ambulatorio, MacchinarioDiDiagnostica\n" +
                                "WHERE Ambulatorio.CodiceAmbulatorio= MacchinarioDiDiagnostica.CodiceAmbulatorio \n"+
                                "GROUP BY Ambulatorio.CodiceAmbulatorio;"
                        );  String dataInst,modello,fornitore,descrizione;
                        int codAmb,numeroSerie;
                        JTextArea area= (JTextArea)this.showP.getComponent(0);
                        area.setText("");
                        while(rs.next()){
                            codAmb= (rs.getInt("CodiceAmbulatorio"));
                            numeroSerie= (rs.getInt("NumeroSerie"));
                            dataInst= (rs.getString("DataInstallazione"));
                            modello=(rs.getString("Modello"));
                            fornitore=(rs.getString("Fornitore"));
                            descrizione=( rs.getString("Descrizione"));
                            
                            area.append("Codice ambulatorio e numero serie macchinario: "+"[ "+ codAmb+" ] "
                                    +numeroSerie+'\n'+
                                    "Data installazione: "+dataInst+" Modello: "+
                                    modello + " Fornitore: "+ fornitore+ '\n'
                            );

                            if(descrizione.length()>60){
                                String sub_descr_other_side;
                                String sub_descr= descrizione.substring(0, 80);
                                String array[]= {"a","e","i","o","u"};
                                boolean itdoes_end_with_vocals=false;
                                for(int i=0;i<5;i++){
                                    if(sub_descr.endsWith(array[i])) itdoes_end_with_vocals=true;
                                }
                                if(itdoes_end_with_vocals==false){
                                    sub_descr= descrizione.substring(0, 81);
                                    sub_descr_other_side= descrizione.substring(81,descrizione.length());
                                }
                                else
                                    sub_descr_other_side= descrizione.substring(80,descrizione.length());
                                
                                area.append(
                                        "Descrizione:"+'\n'+sub_descr+'\n'
                                                +sub_descr_other_side+'\n'
                                );
                                
                            }
                            else {
                                area.append(
                                        "Descrizione:"+'\n'+descrizione+'\n'
                                );
                            }
                        }
                }
                rs.close();
            }
            if(s.compareTo("Query 8")==0){
                ResultSet rs;
                try (Statement stmt = con.createStatement()) {
                    rs = stmt.executeQuery
                        ("SELECT Paziente.CodiceFiscale, Paziente.Nome, Paziente.Cognome, Paziente.Padre, Paziente.Madre, Paziente.LuogoNascita, Paziente.DataNascita\n" +
                                "FROM Paziente, Visita, PersonaleDellaStruttura\n" +
                                "WHERE Paziente.CodiceFiscale = Visita.CodiceFiscale AND Visita.NumeroTesserinoSp = PersonaleDellaStruttura.NumeroTesserino\n" +
                                "AND Sesso = 'M' AND PersonaleDellaStruttura.Nome = 'Virgilio' AND PersonaleDellaStruttura.Cognome = 'Rossi'\n" +
                                "AND NOT EXISTS(\n" + "SELECT *\n" +"FROM Visita AS V, PersonaleDellaStruttura AS PS\n" +
                                "WHERE V.NumeroTesserinoSp = PS.NumeroTesserino AND V.CodiceFiscale = Paziente.CodiceFiscale\n" +
                                "AND PS.Nome = 'Giulio' AND PS.Cognome = 'Verdi'\n" +");"
                        );  String cf,nome,cognome,padre,madre,luogon,datan;
                        JTextArea area= (JTextArea)this.showP.getComponent(0);
                        area.setText("");
                        while(rs.next()){
                            cf= (rs.getString("CodiceFiscale"));
                            nome= (rs.getString("Nome"));
                            cognome= (rs.getString("Cognome"));
                            padre=(rs.getString("Padre"));
                            madre=(rs.getString("Madre"));
                            luogon=( rs.getString("LuogoNascita"));
                            datan=( rs.getString("DataNascita"));
                            
                            area.append("Codice Fiscale, nome e cognome del paziente: "+'\n'
                                    +cf+", "+nome+", "+cognome+'\n'+
                                    "Genitori: "+padre+", "+madre+'\n'+
                                    "Luogo e data di nascita: " + luogon+" "+datan+'\n'
                            );
                            
                            
                        }
                }
                rs.close();
                
            }
            if(s.compareTo("Query 9")==0){              
                PreparedStatement pstmt;               
                ResultSet rs;
                pstmt = con.prepareStatement(
                "SELECT T.DataInizio, T.DataFine, T.CodiceFiscale, T.NumeroTesserinoSp\n" +
                "FROM Terapia AS T, Costituita, Farmaco AS F\n" +
                "WHERE T.DataInizio = Costituita.DataInizio AND T.DataFine = Costituita.DataFine AND T.CodiceFiscale = Costituita.CodiceFiscale AND T.NumeroTesserinoSp = Costituita.NumeroTesserinoSp\n" +
                "  AND F.CodiceFarmaco = Costituita.CodiceFarmaco AND F.CasaFarmaceutica = 'Menarini'\n" +
                "UNION (\n" +
                "SELECT T2.DataInizio, T2.DataFine, T2.CodiceFiscale, T2.NumeroTesserinoSp\n" +
                "FROM Terapia AS T2, Costituita AS C2, Farmaco AS F2\n" +
                "WHERE T2.DataInizio = C2.DataInizio AND T2.DataFine = C2.DataFine AND T2.CodiceFiscale = C2.CodiceFiscale AND T2.NumeroTesserinoSp = C2.NumeroTesserinoSp\n" +
                "AND F2.CodiceFarmaco = C2.CodiceFarmaco AND F2.CasaFarmaceutica = 'Novartis'\n" +
                "    );"        
                );  
                rs = pstmt.executeQuery();
                String DataInizio,DataFine,CodiceFiscale;  
                int NumeroTesserinoSp;
                JTextArea area= (JTextArea)this.showP.getComponent(0);                
                area.setText("");
                while(rs.next()){    
                    DataInizio= (rs.getString("DataInizio"));                    
                    DataFine= (rs.getString("DataFine"));
                    CodiceFiscale=(rs.getString("CodiceFiscale"));
                    NumeroTesserinoSp=( rs.getInt("NumeroTesserinoSp"));                  
                    area.append("Data inizio e fine terapia:"+'\n'
                            +DataInizio+", "+DataFine+'\n'+
                        "Codice fiscale del paziente e numero tesserino dello specialista:"+'\n'
                            +CodiceFiscale+", "+NumeroTesserinoSp+'\n'                                                                          
                    );        
                    
                             
                }
                
            }
             if(s.compareTo("Query 10")==0){
                 ResultSet rs;
                try (Statement stmt = con.createStatement()) {
                    rs = stmt.executeQuery
                    ("SELECT DISTINCT PersonaleDellaStruttura.*, Specialista.*\n" +
                    "FROM PersonaleDellaStruttura INNER JOIN (Visita NATURAL JOIN Specialista) \n" +
                    "ON PersonaleDellaStruttura.NumeroTesserino = Visita.NumeroTesserinoSp\n" +
                    "WHERE (PersonaleDellaStruttura.Nome, PersonaleDellaStruttura.Cognome) != ('Paolo', 'Bianchi')\n" +
                    "AND Visita.NumeroTesserinoSp "
                  + "NOT IN(\n" +
                       "SELECT Visita.NumeroTesserinoSp\n" +
                       "FROM Visita\n" +
                       "WHERE Visita.CodiceFiscale "
                            + "NOT IN (\n" +
                            "SELECT V2.CodiceFiscale\n" +
                            "FROM Visita AS V2, PersonaleDellaStruttura AS PS2\n" +
                            "WHERE PS2.NumeroTesserino = V2.NumeroTesserinoSp\n" +
                            "AND PS2.Nome = 'Paolo' AND PS2.Cognome = 'Bianchi'\n" +
                            ")\n" +
                    ");");
                String nome,cognome,tipocon,spec,email,telefono;  
                int numeroTes,eta,anniserv,codamb;
                JTextArea area= (JTextArea)this.showP.getComponent(0);                
                area.setText("");
                     while(rs.next()){    
                    numeroTes= (rs.getInt("NumeroTesserino"));
                    nome= (rs.getString("Nome"));                    
                    cognome= (rs.getString("Cognome"));
                    eta= (rs.getInt("Età"));
                    tipocon=(rs.getString("TipoContratto"));
                    spec=(rs.getString("Specializzazione"));
                    anniserv=( rs.getInt("AnniServizio"));
                    email=( rs.getString("Email"));
                    telefono=( rs.getString("TelefonoSpecialista"));
                    codamb=( rs.getInt("CodiceAmbulatorio"));                   
                    
                    area.append("Numero tessera, nome, cognome e età dello specialista: "+'\n'
                            +numeroTes+", "+nome+", "+cognome+", "+eta+'\n'+
                        "Tipo contratto, specializzazione e anni di servizio:"+'\n'
                            +tipocon+", "+spec+", "+anniserv+'\n'+                          
                        "Email, telefono e codice ambulatorio:"+'\n'
                            +email+", "+telefono+", "+codamb+'\n'                                                                            
                    );        
                    
                             
                }
                }
                rs.close();
                
            }
            if(s.compareTo("Query Inserimento")==0){
               FrameInserimento frame_ins= new FrameInserimento(con);
            }
        }
        catch(SQLException e){
            System.out.println(e.getMessage());
                
        }
    }
       
                                  
}
              
