package oop21.progettobd;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import javax.swing.*;

public class AddActionListener1_0 implements ActionListener{
    public JPanel inputPanel;
    Connection con;
    YetAnotherListener ln= new YetAnotherListener();
    ///flag di controllo per verificare se i form sono
    ///visibili o meno
    public boolean setPaziente= false;
    public boolean setVisita= false;
    public boolean setPersonale= false;
    public boolean setSpecialista= false;
    public boolean setAssistito= false;
    public boolean setTerapia= false;
    public boolean setCollaboratore=false;
    public boolean setResponsabile=false;
    public boolean setEcografia= false;
            
    @Override
    public void actionPerformed(ActionEvent ae) {
        String s= ae.getActionCommand();
        if(s.compareTo("Ins Paziente")==0){ 
            if(setVisita==true || setPersonale==true || setSpecialista==true 
               ||setAssistito==true ||setTerapia==true || setCollaboratore==true
               ||setResponsabile==true ||setEcografia==true    ){
                setVisita=false;
                setPersonale=false;
                setSpecialista=false;
                setAssistito= false;
                setTerapia= false;
                setCollaboratore=false;
                setResponsabile= false;
                setEcografia=false;
                removeOlderComponent(inputPanel);
            }
            
            if(setPaziente==false){               
            //Dichiarazione di tutto il bordello dei componenti INIZIO   
            JLabel labcf= new JLabel("Codice fiscale:");            
            JTextField cf= new JTextField("");
            JLabel labpadre= new JLabel("Padre:");
            JTextField padre= new JTextField("");   
            JLabel labmadre= new JLabel("Madre:");
            JTextField madre= new JTextField("");
            JLabel labnome= new JLabel("Nome:");
            JTextField nome= new JTextField("");
            JLabel labcognome= new JLabel("Cognome:");
            JTextField cognome= new JTextField("");
            JRadioButton m= new JRadioButton("M");
            JRadioButton f= new JRadioButton("F");            
            JLabel labluogonas= new JLabel("Luogo Nascita:");
            JTextField luogonas= new JTextField("");            
            JLabel labdatanas= new JLabel("Data Nascita: Anno-Mese-Giorno");
            JTextField datanas= new JTextField("");
            ButtonGroup bg= new ButtonGroup();
            bg.add(m);
            bg.add(f);
            JButton confirm= new JButton("Conferma");
            //Dichiarazione di tutto il bordello dei componenti FINE
                       
            Dimension dim_txt_fields= new Dimension(400,20);
            cf.setPreferredSize(dim_txt_fields);
            padre.setPreferredSize(dim_txt_fields);
            madre.setPreferredSize(dim_txt_fields);
            nome.setPreferredSize(dim_txt_fields);
            cognome.setPreferredSize(dim_txt_fields);
            luogonas.setPreferredSize(dim_txt_fields);
            datanas.setPreferredSize(dim_txt_fields);
            
            cf.setMaximumSize(dim_txt_fields);
            padre.setMaximumSize(dim_txt_fields);
            madre.setMaximumSize(dim_txt_fields);
            nome.setMaximumSize(dim_txt_fields);
            cognome.setMaximumSize(dim_txt_fields);       
            luogonas.setMaximumSize(dim_txt_fields);
            datanas.setMaximumSize(dim_txt_fields);       
            
            //Aggiunge tutti i componenti nel panello INIZIO
            inputPanel.add(labcf);
            inputPanel.add(cf);
            inputPanel.add(labpadre);
            inputPanel.add(padre);
            inputPanel.add(labmadre);
            inputPanel.add(madre);
            inputPanel.add(labnome);
            inputPanel.add(nome);
            inputPanel.add(labcognome);
            inputPanel.add(cognome);
            inputPanel.add(m);
            inputPanel.add(f);    
            inputPanel.add(labluogonas);
            inputPanel.add(luogonas);
            inputPanel.add(labdatanas);
            inputPanel.add(datanas);
            inputPanel.add(confirm);
            //Aggiunge tutti i componenti nel panello FINE
            
            setPaziente=true;
            
            inputPanel.revalidate();
            inputPanel.repaint();
                        
            confirm.addActionListener(ln);
            ln.getStuff(inputPanel,s,con,bg);
            }
        }
        if(s.compareTo("Ins Visita")==0){
            if(setPaziente==true || setPersonale==true || setSpecialista==true 
               || setAssistito==true ||setTerapia==true || setCollaboratore==true
               || setResponsabile==true ||setEcografia==true    ){
             //set paziente non è caricato
            setPaziente=false;
            setSpecialista=false;
            setPersonale= false;
            setAssistito= false;
            setTerapia= false;
            setCollaboratore=false;
            setResponsabile= false;
            setEcografia=false;
            removeOlderComponent(inputPanel);           
            }            
            if(setVisita==false){
             //Dichiarazione di tutto il bordello dei componenti INIZIO   
             
            JLabel labora= new JLabel("Ora: Ora-Minuti-Secondi");            
            JTextField ora= new JTextField("");
            JLabel labtipo= new JLabel("Tipo:");
            JTextField tipo= new JTextField("");   
            JLabel labdatav= new JLabel("DataV Anno-Mese-Giorno:");
            JTextField datav= new JTextField("");
            JLabel labcf= new JLabel("Codice fiscale paziente:");
            JTextField cf= new JTextField("");
            JLabel labts= new JLabel("Numero tesserino specialista:");
            JTextField tess= new JTextField("");
            JButton confirm= new JButton("Conferma");
            //Dichiarazione di tutto il bordello dei componenti FINE
                       
            Dimension dim_txt_fields= new Dimension(400,20);
            ora.setPreferredSize(dim_txt_fields);
            tipo.setPreferredSize(dim_txt_fields);
            datav.setPreferredSize(dim_txt_fields);
            cf.setPreferredSize(dim_txt_fields);
            tess.setPreferredSize(dim_txt_fields);
            
            ora.setMaximumSize(dim_txt_fields);
            tipo.setMaximumSize(dim_txt_fields);
            datav.setMaximumSize(dim_txt_fields);
            cf.setMaximumSize(dim_txt_fields);
            tess.setMaximumSize(dim_txt_fields);     
            
            //Aggiunge tutti i componenti nel panello INIZIO
            inputPanel.add(labora);
            inputPanel.add(ora);
            inputPanel.add(labtipo);
            inputPanel.add(tipo);
            inputPanel.add(labdatav);
            inputPanel.add(datav);
            inputPanel.add(labcf);
            inputPanel.add(cf);
            inputPanel.add(labts);
            inputPanel.add(tess);
            inputPanel.add(confirm);
            //Aggiunge tutti i componenti nel panello FINE
            
            setVisita=true;
            
            inputPanel.revalidate();
            inputPanel.repaint();
                        
            confirm.addActionListener(ln);
            ln.getStuff(inputPanel,s,con);
            }   
        }    
            if(s.compareTo("Ins Personale")==0){ 
                if(setVisita==true || setPaziente==true || setSpecialista==true 
                   ||setAssistito==true || setTerapia==true || setCollaboratore==true
                   ||setResponsabile==true || setEcografia==true    ){
                    setVisita=false;
                    setPaziente=false;
                    setSpecialista=false;
                    setAssistito= false;
                    setTerapia= false;
                    setCollaboratore=false;
                    setResponsabile= false;
                    setEcografia=false;
                    removeOlderComponent(inputPanel);
                }
                if(setPersonale==false){               
                //Dichiarazione di tutto il bordello dei componenti INIZIO   
                JLabel labtess= new JLabel("Tesserino del personale:");            
                JTextField tess= new JTextField("");
                JLabel labnome= new JLabel("Nome:");
                JTextField nome= new JTextField("");   
                JLabel labcognome= new JLabel("Cognome:");
                JTextField cognome= new JTextField("");
                JLabel labeta= new JLabel("Età (compresa tra i 35 e i 66 anni):");
                JTextField eta= new JTextField("");            
                JLabel labtipoco= new JLabel("Tipologia di contratto lavorativo (Parziale o Indeterminato)");
                JTextField tipoco= new JTextField("");
                JButton confirm= new JButton("Conferma");
                //Dichiarazione di tutto il bordello dei componenti FINE
                       
                Dimension dim_txt_fields= new Dimension(400,20);
                tess.setPreferredSize(dim_txt_fields);
                nome.setPreferredSize(dim_txt_fields);
                cognome.setPreferredSize(dim_txt_fields);
                eta.setPreferredSize(dim_txt_fields);
                tipoco.setPreferredSize(dim_txt_fields);
            
                tess.setMaximumSize(dim_txt_fields);
                nome.setMaximumSize(dim_txt_fields);
                cognome.setMaximumSize(dim_txt_fields);       
                eta.setMaximumSize(dim_txt_fields);
                tipoco.setMaximumSize(dim_txt_fields);                   
                //Aggiunge tutti i componenti nel panello INIZIO
                inputPanel.add(labtess);
                inputPanel.add(tess);
                inputPanel.add(labnome);
                inputPanel.add(nome);
                inputPanel.add(labcognome);
                inputPanel.add(cognome);
                inputPanel.add(labeta);
                inputPanel.add(eta);
                inputPanel.add(labtipoco);
                inputPanel.add(tipoco);
                inputPanel.add(confirm);
                //Aggiunge tutti i componenti nel panello FINE            
                setPersonale=true;
            
                inputPanel.revalidate();
                inputPanel.repaint();
                        
                confirm.addActionListener(ln);
                ln.getStuff(inputPanel,s,con);
            }
        }
        if(s.compareTo("Ins Specialista")==0){ 
            if(setVisita==true || setPaziente==true || setPersonale==true 
               || setAssistito==true || setTerapia==true || setCollaboratore==true
               || setResponsabile==true || setEcografia==true     ){
                setVisita=false;
                setPaziente=false;
                setPersonale= false;
                setAssistito= false;
                setTerapia= false;
                setCollaboratore=false;
                setResponsabile= false;
                setEcografia=false;
                removeOlderComponent(inputPanel);
            }
            
            if(setSpecialista==false){               
            //Dichiarazione di tutto il bordello dei componenti INIZIO   
            JLabel labtess= new JLabel("Tesserino dello specialista:");            
            JTextField tess= new JTextField("");
            JLabel labspec= new JLabel("Specializzazione:");
            JTextField spec= new JTextField("");   
            JLabel labannis= new JLabel("Anni di servizio:");
            JTextField annis= new JTextField("");
            JLabel labemail= new JLabel("Email nella forma (%.%@poliambulatoriopediatrico.it):");
            JTextField email= new JTextField("");            
            JLabel labtel= new JLabel("Telefono nella forma('+39 ___ ___ ____' al posto dei ___ inserire numero");
            JTextField tel= new JTextField("");            
            JLabel labcodamb= new JLabel("Codice dell'ambulatorio:");
            JTextField codamb= new JTextField("");
            JButton confirm= new JButton("Conferma");
            //Dichiarazione di tutto il bordello dei componenti FINE
                       
            Dimension dim_txt_fields= new Dimension(400,20);
            tess.setPreferredSize(dim_txt_fields);
            spec.setPreferredSize(dim_txt_fields);
            annis.setPreferredSize(dim_txt_fields);
            email.setPreferredSize(dim_txt_fields);
            tel.setPreferredSize(dim_txt_fields);
            codamb.setPreferredSize(dim_txt_fields);
            
            tess.setMaximumSize(dim_txt_fields);
            spec.setMaximumSize(dim_txt_fields);
            annis.setMaximumSize(dim_txt_fields);       
            email.setMaximumSize(dim_txt_fields);
            tel.setMaximumSize(dim_txt_fields);       
            codamb.setMaximumSize(dim_txt_fields);       
            
            //Aggiunge tutti i componenti nel panello INIZIO
            inputPanel.add(labtess);
            inputPanel.add(tess);
            inputPanel.add(labspec);
            inputPanel.add(spec);
            inputPanel.add(labannis);
            inputPanel.add(annis);
            inputPanel.add(labemail);
            inputPanel.add(email);
            inputPanel.add(labtel);
            inputPanel.add(tel);
            inputPanel.add(labcodamb);
            inputPanel.add(codamb);
            inputPanel.add(confirm);
            //Aggiunge tutti i componenti nel panello FINE
            
            setSpecialista=true;
            
            inputPanel.revalidate();
            inputPanel.repaint();
                        
            confirm.addActionListener(ln);
            ln.getStuff(inputPanel,s,con);
            }
        }
        
        
        if(s.compareTo("Ins Assistito")==0){ 
            if(setVisita==true || setPaziente==true || setPersonale==true 
               || setSpecialista==true || setTerapia==true || setCollaboratore==true
               || setResponsabile==true || setEcografia==true    ){
                setVisita=false;
                setPaziente=false;
                setPersonale= false;
                setSpecialista= false;
                setTerapia= false;
                setCollaboratore=false;
                setResponsabile= false;
                setEcografia=false;
                removeOlderComponent(inputPanel);
            }
            
            if(setAssistito==false){               
            //Dichiarazione di tutto il bordello dei componenti INIZIO   
            JLabel labtess= new JLabel("Numero tesserino dello specialista:");            
            JTextField tess= new JTextField("");
            JLabel labtessco= new JLabel("Numero tesserino del collaboratore:");
            JTextField tessco= new JTextField("");   
            JButton confirm= new JButton("Conferma");
            //Dichiarazione di tutto il bordello dei componenti FINE
                       
            Dimension dim_txt_fields= new Dimension(150,20);
            tess.setPreferredSize(dim_txt_fields);
            tessco.setPreferredSize(dim_txt_fields);            
            
            tess.setMaximumSize(dim_txt_fields);
            tessco.setMaximumSize(dim_txt_fields);            
            //Aggiunge tutti i componenti nel panello INIZIO
            inputPanel.add(labtess);
            inputPanel.add(tess);
            inputPanel.add(labtessco);
            inputPanel.add(tessco);
            inputPanel.add(confirm);
            //Aggiunge tutti i componenti nel panello FINE
            
            setAssistito=true;
            
            inputPanel.revalidate();
            inputPanel.repaint();
                        
            confirm.addActionListener(ln);
            ln.getStuff(inputPanel,s,con);
            }
        }
        
        if(s.compareTo("Ins Terapia")==0){ 
            if(setVisita==true || setPaziente==true || setPersonale==true 
               || setSpecialista==true || setAssistito==true || setCollaboratore==true
               || setResponsabile==true || setEcografia==true    ){
                setVisita=false;
                setPaziente=false;
                setPersonale= false;
                setSpecialista= false;
                setAssistito= false;
                setCollaboratore=false;
                setResponsabile=false;
                setEcografia=false;
                removeOlderComponent(inputPanel);
            }
            
            if(setTerapia==false){               
            //Dichiarazione di tutto il bordello dei componenti INIZIO   
            JLabel labdatain= new JLabel("Data inizio terapia nel formato Anno-Mese-Giorno:");            
            JTextField datain= new JTextField("");
            JLabel labdataf= new JLabel("Data fine terapia nel formato Anno-Mese-Giorno:");
            JTextField dataf= new JTextField("");
            JLabel labmalattia= new JLabel("Malattia:");
            JTextField malattia= new JTextField("");   
            JLabel labcf= new JLabel("Codice fiscale del paziente:");
            JTextField cf= new JTextField("");   
            JLabel labnumtess= new JLabel("Numero tesserino dello specialista:");
            JTextField numtess= new JTextField("");   
            
            JButton confirm= new JButton("Conferma");
            //Dichiarazione di tutto il bordello dei componenti FINE
                       
            Dimension dim_txt_fields= new Dimension(260,20);
            datain.setPreferredSize(dim_txt_fields);
            dataf.setPreferredSize(dim_txt_fields);            
            malattia.setPreferredSize(dim_txt_fields);            
            cf.setPreferredSize(dim_txt_fields);            
            numtess.setPreferredSize(dim_txt_fields);            
            
            datain.setMaximumSize(dim_txt_fields);
            dataf.setMaximumSize(dim_txt_fields);
            malattia.setMaximumSize(dim_txt_fields);            
            cf.setMaximumSize(dim_txt_fields);
            numtess.setMaximumSize(dim_txt_fields);            
               
            
            //Aggiunge tutti i componenti nel panello INIZIO
            inputPanel.add(labdatain);
            inputPanel.add(datain);
            inputPanel.add(labdataf);
            inputPanel.add(dataf);
            inputPanel.add(labmalattia);
            inputPanel.add(malattia);
            inputPanel.add(labcf);
            inputPanel.add(cf);
            inputPanel.add(labnumtess);
            inputPanel.add(numtess);
            inputPanel.add(confirm);
            //Aggiunge tutti i componenti nel panello FINE
            
            setTerapia=true;
            
            inputPanel.revalidate();
            inputPanel.repaint();
                        
            confirm.addActionListener(ln);
            ln.getStuff(inputPanel,s,con);
            }
        }
    
    if(s.compareTo("Ins Collaboratore")==0){ 
            if(setVisita==true || setPaziente==true || setPersonale==true 
               || setSpecialista==true || setAssistito==true || setTerapia==true
               || setResponsabile==true || setEcografia==true    ){
                setVisita=false;
                setPaziente=false;
                setPersonale= false;
                setSpecialista= false;
                setAssistito= false;
                setTerapia=false;
                setResponsabile=false;
                setEcografia=false;
                removeOlderComponent(inputPanel);
            }
            
            
            if(setCollaboratore==false){               
            //Dichiarazione di tutto il bordello dei componenti INIZIO   
            JLabel labtessco= new JLabel("Numero tesserino del collaboratore:");            
            JTextField tessco= new JTextField("");
            JLabel labnum= new JLabel("Numero dei macchinari gestiti dal collaboratore:");
            JTextField num= new JTextField("");
            JLabel labspec= new JLabel("Specializzazione:");
            JTextField spec= new JTextField("");   
            
            JButton confirm= new JButton("Conferma");
            //Dichiarazione di tutto il bordello dei componenti FINE
                       
            Dimension dim_txt_fields= new Dimension(260,20);
            tessco.setPreferredSize(dim_txt_fields);
            num.setPreferredSize(dim_txt_fields);            
            spec.setPreferredSize(dim_txt_fields);            
            
            tessco.setMaximumSize(dim_txt_fields);
            num.setMaximumSize(dim_txt_fields);
            spec.setMaximumSize(dim_txt_fields);            
            
            //Aggiunge tutti i componenti nel panello INIZIO
            inputPanel.add(labtessco);
            inputPanel.add(tessco);
            inputPanel.add(labnum);
            inputPanel.add(num);
            inputPanel.add(labspec);
            inputPanel.add(spec);
            
            inputPanel.add(confirm);
            //Aggiunge tutti i componenti nel panello FINE
            
            setCollaboratore=true;
            
            inputPanel.revalidate();
            inputPanel.repaint();
                        
            confirm.addActionListener(ln);
            ln.getStuff(inputPanel,s,con);
            }
        }    
    
    if(s.compareTo("Ins Responsabile")==0){ 
            if(setVisita==true || setPaziente==true || setPersonale==true 
               || setSpecialista==true || setAssistito==true || setTerapia==true
               || setCollaboratore==true || setEcografia==true     ){
                setVisita=false;
                setPaziente=false;
                setPersonale= false;
                setSpecialista= false;
                setAssistito= false;
                setTerapia=false;
                setCollaboratore=false;
                setEcografia= false;
                removeOlderComponent(inputPanel);
            }
            
            
            if(setResponsabile==false){                               
            //Dichiarazione di tutto il bordello dei componenti INIZIO   
            JLabel labtessco= new JLabel("Numero tesserino del collaboratore:");            
            JTextField tessco= new JTextField("");
            JLabel labnum= new JLabel("Numero serie del macchinario:");
            JTextField num= new JTextField("");
            JLabel labcodamb= new JLabel("Codice ambulatorio:");
            JTextField codamb= new JTextField("");   
            
            JButton confirm= new JButton("Conferma");
            //Dichiarazione di tutto il bordello dei componenti FINE
                       
            Dimension dim_txt_fields= new Dimension(260,20);
            tessco.setPreferredSize(dim_txt_fields);
            num.setPreferredSize(dim_txt_fields);            
            codamb.setPreferredSize(dim_txt_fields);            
            
            tessco.setMaximumSize(dim_txt_fields);
            num.setMaximumSize(dim_txt_fields);
            codamb.setMaximumSize(dim_txt_fields);            
            
            //Aggiunge tutti i componenti nel panello INIZIO
            inputPanel.add(labtessco);
            inputPanel.add(tessco);
            inputPanel.add(labnum);
            inputPanel.add(num);
            inputPanel.add(labcodamb);
            inputPanel.add(codamb);
            
            inputPanel.add(confirm);
            //Aggiunge tutti i componenti nel panello FINE
            
            setResponsabile=true;
            
            inputPanel.revalidate();
            inputPanel.repaint();
                        
            confirm.addActionListener(ln);
            ln.getStuff(inputPanel,s,con);
            }
        }
    
    if(s.compareTo("Ins Ecografia")==0){ 
            if(setVisita==true || setPaziente==true || setPersonale==true 
               || setSpecialista==true || setAssistito==true || setTerapia==true
               || setCollaboratore==true || setResponsabile==true     ){
                setVisita=false;
                setPaziente=false;
                setPersonale= false;
                setSpecialista= false;
                setAssistito= false;
                setTerapia=false;
                setCollaboratore=false;
                setResponsabile= false;
                removeOlderComponent(inputPanel);
            }
            
            
            if(setEcografia==false){                               
            //Dichiarazione di tutto il bordello dei componenti INIZIO   
            JLabel labtessco= new JLabel("Numero tesserino del collaboratore:");            
            JTextField tessco= new JTextField("");
            JLabel labnum= new JLabel("Numero serie del macchinario:");
            JTextField num= new JTextField("");
            JLabel labcodamb= new JLabel("Codice ambulatorio:");
            JTextField codamb= new JTextField("");   
            
            JButton confirm= new JButton("Conferma");
            //Dichiarazione di tutto il bordello dei componenti FINE
                       
            Dimension dim_txt_fields= new Dimension(260,20);
            tessco.setPreferredSize(dim_txt_fields);
            num.setPreferredSize(dim_txt_fields);            
            codamb.setPreferredSize(dim_txt_fields);            
            
            tessco.setMaximumSize(dim_txt_fields);
            num.setMaximumSize(dim_txt_fields);
            codamb.setMaximumSize(dim_txt_fields);            
            
            //Aggiunge tutti i componenti nel panello INIZIO
            inputPanel.add(labtessco);
            inputPanel.add(tessco);
            inputPanel.add(labnum);
            inputPanel.add(num);
            inputPanel.add(labcodamb);
            inputPanel.add(codamb);
            
            inputPanel.add(confirm);
            //Aggiunge tutti i componenti nel panello FINE
            
            setEcografia=true;
            
            inputPanel.revalidate();
            inputPanel.repaint();
                        
            confirm.addActionListener(ln);
            ln.getStuff(inputPanel,s,con);
            }
        }
    
    if(s.compareTo("Reset Form")==0){
        setVisita=false;
        setPaziente=false;
        setPersonale= false;
        setSpecialista= false;
        setAssistito= false;
        setTerapia= false;
        setCollaboratore= false;
        setResponsabile= false;
        setEcografia= false;
        removeOlderComponent(inputPanel);
        
    }   
}
    public void getStuff(JPanel inputP,Connection con){
        this.inputPanel= inputP;
        this.con= con;
    }
    public void removeOlderComponent(JPanel p){
        p.removeAll();
        BoxLayout layout = new BoxLayout(p, BoxLayout.Y_AXIS);        
        p.setLayout(layout);        
        p.revalidate();
        p.repaint();
    }
    
}
