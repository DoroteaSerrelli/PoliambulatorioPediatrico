package oop21.progettobd;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.Enumeration;
import javax.swing.*;

public class YetAnotherListener implements ActionListener{
    JPanel p;
    String s;
    Connection con;
    ButtonGroup bg;
    JTextArea area;
    String s1,s2,s3,s4,s5,s6,s7;
    JTextField p1,p2,p3,p4,p5,p6,p7;
            
    @Override
    public void actionPerformed(ActionEvent ae) {
        if(s.compareTo("Ins Paziente")==0){
            JTextField p1= (JTextField)p.getComponent(1);
            //padre madre nome cognome sesso luogo nascita data nascita
            p2=(JTextField)p.getComponent(3);
            p3=(JTextField)p.getComponent(5);
            p4=(JTextField)p.getComponent(7);
            p5=(JTextField)p.getComponent(9);
            p6=(JTextField)p.getComponent(13);
            p7=(JTextField)p.getComponent(15);
            
            //10-11 sesso
            JRadioButton pm=(JRadioButton)p.getComponent(10);
            JRadioButton pf=(JRadioButton)p.getComponent(11);          
            s1= p1.getText(); //cf
            s2= p2.getText(); //padre
            s3= p3.getText(); //madre
            s4= p4.getText();// nome
            s5= p5.getText();//cognome
            String ss="";
            
            //sesso: //Dovrebbe iterare fin quando non trova il pulsante attivato e restituire
            //il testo
            for (Enumeration<AbstractButton> buttons = bg.getElements(); buttons.hasMoreElements();) {
            AbstractButton button = buttons.nextElement();

                if (button.isSelected()) {
                ss= button.getText();
                }
            }
            
            s6= p6.getText();//luogonascita
            s7= p7.getText();//datanascita
              PreparedStatement pstmt;
              //ResultSet rs;
            try {                               
                String query=
                     ("INSERT INTO Paziente (CodiceFiscale, Padre, Madre, Nome, Cognome, Sesso, LuogoNascita, DataNascita) "
                     + "VALUES(?, ?, ?, ?, ?, ?, ?, ?);"                  
                );                
                pstmt = con.prepareStatement(query);
                pstmt.setString(1,s1); 
                pstmt.setString(2,s2);                                 
                pstmt.setString(3,s3);  
                pstmt.setString(4,s4);                    
                pstmt.setString(5,s5);                    
                pstmt.setString(6,ss);                 
                pstmt.setString(7,s6); 
                pstmt.setString(8,s7); 
                
                pstmt.executeUpdate(); 
                
                JOptionPane.showMessageDialog(null,"Inserimento avvenuto con sucesso");
                removeOlderComponent(p);
                
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }
        if(s.compareTo("Ins Personale")==0){            
            p1=(JTextField)p.getComponent(1);//num tess 20 - 20+
            p2=(JTextField)p.getComponent(3);//nome
            p3=(JTextField)p.getComponent(5);//cognome
            p4=(JTextField)p.getComponent(7);//eta
            p5=(JTextField)p.getComponent(9);//tipo contratto
                
            s1= p1.getText(); 
            s2= p2.getText(); 
            s3= p3.getText(); 
            s4= p4.getText();
            s5= p5.getText();
            PreparedStatement pstmt;
              //ResultSet rs;
            try {                               
                String query=
                     ("INSERT INTO PersonaleDellaStruttura (NumeroTesserino, Nome, Cognome, Età, TipoContratto) "
                     + "VALUES(?, ?, ?, ?, ?);"                  
                );                
                pstmt = con.prepareStatement(query);
                pstmt.setString(1,s1); 
                pstmt.setString(2,s2);                                
                pstmt.setString(3,s3);  
                pstmt.setString(4,s4);                    
                pstmt.setString(5,s5);          
                pstmt.executeUpdate(); 
                
                JOptionPane.showMessageDialog(null,"Inserimento avvenuto con sucesso");                
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
                JOptionPane.showMessageDialog(null, "Si e' verificato un problema durante l'inserimento");
            }
        }
        
        if(s.compareTo("Ins Visita")==0){
            //Ora Tipo Datavisita cf numeroTess
            p1=(JTextField)p.getComponent(1);
            p2=(JTextField)p.getComponent(3);
            p3=(JTextField)p.getComponent(5);
            p4=(JTextField)p.getComponent(7);
            p5=(JTextField)p.getComponent(9);
                
            s1= p1.getText(); //cf
            s2= p2.getText(); //padre
            s3= p3.getText(); //madre
            s4= p4.getText();// nome
            s5= p5.getText();//cognome
            PreparedStatement pstmt;
              //ResultSet rs;
            try {                               
                String query=
                     ("INSERT INTO Visita (Ora, Tipo, DataV, CodiceFiscale, NumeroTesserinoSp) "
                     + "VALUES(?, ?, ?, ?, ?);"                  
                );                
                pstmt = con.prepareStatement(query);
                pstmt.setString(1,s1); 
                pstmt.setString(2,s2);                                
                pstmt.setString(3,s3);  
                pstmt.setString(4,s4);                    
                pstmt.setString(5,s5);          
                pstmt.executeUpdate(); 
                
                JOptionPane.showMessageDialog(null,"Inserimento avvenuto con sucesso");                
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
                if(ex.getErrorCode()==1452){
                    JOptionPane.showMessageDialog(null, "Non è stata trovato nessuno specialista relativo al numero di tesserino inserito"); 
                    try{ 
                        int tess,numamb,annis;
                        String query=
                        ("SELECT * FROM Specialista"                                       
                        );                
                        pstmt = con.prepareStatement(query);
                        ResultSet rs= pstmt.executeQuery();                       
                        area.setText("");
                        while(rs.next()){
                            tess= (rs.getInt("NumeroTesserinoSp")); 
                            s1=( rs.getString("Specializzazione"));
                            annis=(rs.getInt("AnniServizio"));
                            s3=(rs.getString("Email"));
                            s4=(rs.getString("TelefonoSpecialista"));
                            numamb= (rs.getInt("CodiceAmbulatorio")); 
                            
                            area.append("Numero tesserino: "+tess+" Specializzazione : "+ s1+"\n"+
                                            " Anni di servizio: "+annis+
                                        " Email: "+s3+"\n"+ " Telefono: "+s4+ "\n"+
                                        "Numero ambulatorio: "+ numamb + "\n");                           
                        }
                        
                    }
                    catch(SQLException so){
                     JOptionPane.showMessageDialog(null, "Si e' verificato un'errore durante la ricerca degli specialisti");                     
                    }
                }    
                else    
                JOptionPane.showMessageDialog(null, "Si e' verificato un problema durante l'inserimento");
            }
        }
        if(s.compareTo("Ins Specialista")==0){
            p1=(JTextField)p.getComponent(1);
            p2=(JTextField)p.getComponent(3);
            p3=(JTextField)p.getComponent(5);
            p4=(JTextField)p.getComponent(7);
            p5=(JTextField)p.getComponent(9);
            p6=(JTextField)p.getComponent(11);
                
            s1= p1.getText(); //NumeroTesserinoSp
            s2= p2.getText(); //Specializzazione
            s3= p3.getText(); //AnniServizio
            s4= p4.getText();// Email
            s5= p5.getText();//TelefonoSpecialista
            s6= p6.getText();//CodiceAmbulatorio
            PreparedStatement pstmt;
              //ResultSet rs;
            try {                               
                String query=
                     ("INSERT INTO Specialista (NumeroTesserinoSp, Specializzazione, AnniServizio, Email, TelefonoSpecialista,CodiceAmbulatorio) "
                     + "VALUES(?, ?, ?, ?, ?, ?);"                  
                );                
                pstmt = con.prepareStatement(query);
                pstmt.setString(1,s1); 
                pstmt.setString(2,s2);                                
                pstmt.setString(3,s3);  
                pstmt.setString(4,s4);                    
                pstmt.setString(5,s5);
                pstmt.setString(6,s6);
                pstmt.executeUpdate(); 
                
                JOptionPane.showMessageDialog(null,"Inserimento avvenuto con sucesso");                
            } 
            catch (SQLException ex) {
                System.out.println(ex.getMessage());
                if(ex.getErrorCode()==1452){
                    JOptionPane.showMessageDialog(null, "Non è stato trovato nessun Ambulatorio/impiegato della struttura relativo al numero di tesserino inserito");
                     try{                      
                        int codamb,piano; 
                        int tess;            
                        String query=
                        ("SELECT *"
                                + "FROM PersonaleDellaStruttura,Ambulatorio"                                       
                        );                
                        pstmt = con.prepareStatement(query);
                        ResultSet rs= pstmt.executeQuery();                       
                        area.setText("");
                        while(rs.next()){
                            tess= (rs.getInt("NumeroTesserino"));
                            s4= (rs.getString("Nome"));
                            s5= (rs.getString("Cognome"));
                            codamb=(rs.getInt("CodiceAmbulatorio"));
                            piano= (rs.getInt("Piano"));
                            s1= (rs.getString("Ora"));
                            s2= (rs.getString("DataS"));
                            s3= (rs.getString("PartitaIVA"));
                            area.append("Numero tesserino impiegato: "+tess+"\n"+
                                    "Nome e cognome impiegato: "+s4+" "+s5+"\n"+
                                    "Codice ambulatorio: "+codamb+
                                     " Piano:"+piano +"\n"+
                                    "Ora e data ultima sanificazione: "+s1+ " in data: "+s2+"\n"+
                                    "PartitaIVA della ditta di sanificazione: "+s3+"\n"
                              );                           
                        }
                    }
                    catch(SQLException so){
                     System.out.println(so.getMessage());   
                     JOptionPane.showMessageDialog(null, "Si e' verificato un'errore durante la ricerca degli ambulatori");                     
                    }
                }
                    
                else    
                JOptionPane.showMessageDialog(null, "Si e' verificato un problema durante l'inserimento");
                
            }
        }
        if(s.compareTo("Ins Assistito")==0){
            p1=(JTextField)p.getComponent(1);
            p2=(JTextField)p.getComponent(3);           
            p3=(JTextField)p.getComponent(5);
            p4=(JTextField)p.getComponent(7);
                            
            s1= p1.getText(); //NumeroTesserinoSp
            s2= p2.getText(); //NumeroTesserinoCo           
            s3= p1.getText(); //NumeroOre
            s4= p2.getText(); //AnnoCollaborazione
            PreparedStatement pstmt;
              //ResultSet rs;
            try {                               
                String query=
                     ("INSERT INTO Assistito (NumeroTesserinoSp, NumeroTesserinoCo,NumeroOre,AnnoCollaborazione) "
                     + "VALUES(?, ?, ?, ?);"                  
                );                
                pstmt = con.prepareStatement(query);
                pstmt.setString(1,s1); 
                pstmt.setString(2,s2); 
                pstmt.setString(3,s3); 
                pstmt.setString(4,s4); 
                pstmt.executeUpdate(); 
                
                JOptionPane.showMessageDialog(null,"Inserimento avvenuto con sucesso");                
            } 
            catch (SQLException ex) {
                System.out.println(ex.getMessage());
                if(ex.getErrorCode()==1452)
                    JOptionPane.showMessageDialog(null, "Non è stata trovato nessuno specialista/Collaboratore relativo al numero di tesserino inserito");            
                else if(ex.getErrorCode()==1062)
                    JOptionPane.showMessageDialog(null, "La collaborazione inserita potrebbe essere già presente, sono presenti valori duplicati relativi alle chiavi");
                else    
                JOptionPane.showMessageDialog(null, "Si e' verificato un problema durante l'inserimento");
                
            }
        }
    if(s.compareTo("Ins Sanificazione")==0){
            p1=(JTextField)p.getComponent(1);
            p2=(JTextField)p.getComponent(3);
            p3=(JTextField)p.getComponent(5);
            p4=(JTextField)p.getComponent(7);
                
            s1= p1.getText(); //CodiceAmbulatorio
            s2= p2.getText(); //PartitaIVA
            s3= p3.getText(); //Ora
            s4= p4.getText();// DataS
           PreparedStatement pstmt;
              //ResultSet rs;
            try {                               
                String query=
                     ("INSERT INTO Sanificazione (CodiceAmbulatorio, PartitaIVA, Ora, DataS) "
                     + "VALUES(?, ?, ?, ?);"                  
                );                
                pstmt = con.prepareStatement(query);
                pstmt.setString(1,s1); 
                pstmt.setString(2,s2);                                
                pstmt.setString(3,s3);  
                pstmt.setString(4,s4);                    
                pstmt.executeUpdate(); 
                
                JOptionPane.showMessageDialog(null,"Inserimento avvenuto con sucesso");                
            } 
            catch (SQLException ex) {
                System.out.println(ex.getMessage());
                if(ex.getErrorCode()==1452){
                    JOptionPane.showMessageDialog(null, "Non è stato trovato nessun Ambulatorio/Ditta di sanificazione relativo al numero di tesserino inserito");
                     try{                      
                        int codamb,piano;             
                        String query=
                        ("SELECT *"
                                + "FROM Ambulatorio,dittadisanificazione"                                       
                        );                
                        pstmt = con.prepareStatement(query);
                        ResultSet rs= pstmt.executeQuery();                       
                        area.setText("");
                        while(rs.next()){
                            codamb=(rs.getInt("CodiceAmbulatorio"));
                            piano= (rs.getInt("Piano"));
                            s1= (rs.getString("PartitaIVA"));
                            s2= (rs.getString("TelefonoDitta"));
                            area.append( "Codice ambulatorio: "+codamb+
                                     " Piano:"+piano +"\n"+                                   
                                    "PartitaIVA della ditta di sanificazione: "+s1+"\n"+
                                    "Telefono della ditta di sanificazione: "+s2+"\n"
                              );                           
                        }
                    }
                    catch(SQLException so){
                     System.out.println(so.getMessage());   
                     JOptionPane.showMessageDialog(null, "Si e' verificato un'errore durante la ricerca degli ambulatori-ditte");                     
                    }
                }
                    
                else    
                JOptionPane.showMessageDialog(null, "Si e' verificato un problema durante l'inserimento");
                
            }
        }
        
    if(s.compareTo("Ins Terapia")==0){
            p1=(JTextField)p.getComponent(1);//DataInizio
            p2=(JTextField)p.getComponent(3);//DataFine
            p3=(JTextField)p.getComponent(5);//Malattia
            p4=(JTextField)p.getComponent(7);//CodiceFiscale
            p5=(JTextField)p.getComponent(9);//NumeroTesserinoSp
                
            s1= p1.getText(); 
            s2= p2.getText(); 
            s3= p3.getText(); 
            s4= p4.getText();
            s5= p5.getText();
            PreparedStatement pstmt;
              //ResultSet rs;
            try {                               
                String query=
                     ("INSERT INTO Terapia (DataInizio, DataFine, Malattia, CodiceFiscale, NumeroTesserinoSp) "
                     + "VALUES(?, ?, ?, ?, ?);"                  
                );                
                pstmt = con.prepareStatement(query);
                pstmt.setString(1,s1); 
                pstmt.setString(2,s2);                                
                pstmt.setString(3,s3);  
                pstmt.setString(4,s4);                    
                pstmt.setString(5,s5);          
                pstmt.executeUpdate(); 
                
                JOptionPane.showMessageDialog(null,"Inserimento avvenuto con sucesso");                
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
                  if(ex.getErrorCode()==1452){
                    JOptionPane.showMessageDialog(null, "Non è stata trovato nessuno specialista relativo al numero di tesserino inserito"); 
                    try{ 
                        int tess,numamb,annis;
                        String query=
                        ("SELECT * FROM Specialista"                                       
                        );                
                        pstmt = con.prepareStatement(query);
                        ResultSet rs= pstmt.executeQuery();                       
                        area.setText("");
                        while(rs.next()){
                            tess= (rs.getInt("NumeroTesserinoSp")); 
                            s1=( rs.getString("Specializzazione"));
                            annis=(rs.getInt("AnniServizio"));
                            s3=(rs.getString("Email"));
                            s4=(rs.getString("TelefonoSpecialista"));
                            numamb= (rs.getInt("CodiceAmbulatorio")); 
                            
                            area.append("Numero tesserino: "+tess+" Specializzazione : "+ s1+"\n"+
                                            " Anni di servizio: "+annis+
                                        " Email: "+s3+"\n"+ " Telefono: "+s4+ "\n"+
                                        "Numero ambulatorio: "+ numamb + "\n");                           
                        }
                        
                    }
                    catch(SQLException so){
                     JOptionPane.showMessageDialog(null, "Si e' verificato un'errore durante la ricerca degli specialisti");                     
                    }
                }    
                else    
                JOptionPane.showMessageDialog(null, "Si e' verificato un problema durante l'inserimento");
            
            }
        }
        if(s.compareTo("Ins Collaboratore")==0){
            p1=(JTextField)p.getComponent(1);//NumeroTesserinoCo
            p2=(JTextField)p.getComponent(3);//Numero_macchinari
            p3=(JTextField)p.getComponent(5);//Specializzazione
                
            s1= p1.getText(); 
            s2= p2.getText(); 
            s3= p3.getText(); 
            PreparedStatement pstmt;
              //ResultSet rs;
            try {                               
                String query=
                     ("INSERT INTO Collaboratore (NumeroTesserinoCo, Numero_macchinari, Specializzazione) "
                     + "VALUES(?, ?, ?);"                  
                );                
                pstmt = con.prepareStatement(query);
                pstmt.setString(1,s1); 
                pstmt.setString(2,s2);                                
                pstmt.setString(3,s3);  
                pstmt.executeUpdate(); 
                
                JOptionPane.showMessageDialog(null,"Inserimento avvenuto con sucesso");                
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
                if(ex.getErrorCode()==1452)
                    JOptionPane.showMessageDialog(null, "Non è stato trovato nessun impiegato parte del personale relativo al numero tesserino inserito");        
                else    
                JOptionPane.showMessageDialog(null, "Si e' verificato un problema durante l'inserimento");
                
            }
        }
        
        if(s.compareTo("Ins Responsabile")==0){
            p1=(JTextField)p.getComponent(1);//NumeroTesserinoCo
            p2=(JTextField)p.getComponent(3);//NumeroSerie
           
            s1= p1.getText(); 
            s2= p2.getText();
            PreparedStatement pstmt;
            
            try {                               
                String query=
                     ("INSERT INTO Responsabile (NumeroTesserinoCo, NumeroSerie) "
                     + "VALUES(?, ?);"                  
                );                
                pstmt = con.prepareStatement(query);
                pstmt.setString(1,s1); 
                pstmt.setString(2,s2);                                
                pstmt.executeUpdate(); 
                
                query=
                     ("UPDATE Collaboratore SET Collaboratore.Numero_Macchinari = Collaboratore.Numero_Macchinari + 1 "
                     + "WHERE Collaboratore.NumeroTesserinoCo = ?;"                  
                );
                pstmt = con.prepareStatement(query);
                pstmt.setString(1, s1);
                pstmt.executeUpdate(); 
                
                JOptionPane.showMessageDialog(null,"Inserimento avvenuto con sucesso");                
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
                if(ex.getErrorCode()==1452){
                    JOptionPane.showMessageDialog(null, "Non è stato trovato nessuno ambulatorio/collaboratore relativo alle informazioni inserite"); 
                /*    try{                      RIMOSSA POICHE LA TETXAREA OCCUPA LA MAGGIOR PARTE
                        int tess,codamb,piano;  DELLO SPAZIO E NON E' VISIBILMENTE "BELLA" DA VEDERE
                        int numm;               PER QUESTO MOTIVO
                        String query=
                        ("SELECT *"
                                + "FROM Collaboratore,Ambulatorio"                                       
                        );                
                        pstmt = con.prepareStatement(query);
                        ResultSet rs= pstmt.executeQuery();                       
                        area.setText("");
                        while(rs.next()){
                            tess= (rs.getInt("NumeroTesserinoCo")); 
                            numm=( rs.getInt("Numero_Macchinari"));
                            s1=(rs.getString("Specializzazione"));
                            codamb=(rs.getInt("CodiceAmbulatorio"));
                            piano= (rs.getInt("Piano"));
                            area.append("Numero tesserino: "+tess+" Specializzazione : "+ s1+"\n"+                                   
                                        " Numero macchinari: "+numm+"\n"+ " Codice ambulatorio: "+codamb+
                                     " Piano:"+piano +"\n"
                              );                           
                        }
                    }
                    catch(SQLException so){
                     System.out.println(so.getMessage());   
                     JOptionPane.showMessageDialog(null, "Si e' verificato un'errore durante la ricerca degli ambulatori/collaboratori");                     
                    }
                    *//////////////////////////////////////////////////////////////////////////////////    
                }                
                else    
                JOptionPane.showMessageDialog(null, "Si e' verificato un problema durante l'inserimento");
                
            }
            
        }

        if(s.compareTo("Ins Ecografia")==0){
                       
            p1=(JTextField)p.getComponent(1);//CodiceEcografia
            p2=(JTextField)p.getComponent(3);//NomeEcografia
            p3=(JTextField)p.getComponent(5);//CodiceFiscale           
            p4=(JTextField)p.getComponent(7);//NumeroTesserinoSp
            p5=(JTextField)p.getComponent(9);//Descrizione
            
            s1= p1.getText(); 
            s2= p2.getText(); 
            s3= p3.getText(); 
            s4= p4.getText(); 
            s5= p5.getText(); 
            PreparedStatement pstmt;
            
            try {                               
                String query=
                     ("INSERT INTO Ecografia (CodiceEcografia, NomeEcografia, Descrizione, CodiceFiscale, NumeroTesserinoSp) "
                     + "VALUES(?, ?, ?, ?, ?);"                  
                );                
                pstmt = con.prepareStatement(query);
                pstmt.setString(1,s1); 
                pstmt.setString(2,s2);                                
                pstmt.setString(3,s5);                
                pstmt.setString(4,s3);                                
                pstmt.setString(5,s4);
                pstmt.executeUpdate(); 
                
                JOptionPane.showMessageDialog(null,"Inserimento avvenuto con sucesso");                
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
                if(ex.getErrorCode()==1452){
                    JOptionPane.showMessageDialog(null, "Non è stato trovato nessuno specialista/paziente relativo alle informazioni inserite"); 
                    try{ 
                        int tess;
                        String query=
                        ("SELECT *"
                                + "FROM Specialista,Paziente"                                       
                        );                
                        pstmt = con.prepareStatement(query);
                        ResultSet rs= pstmt.executeQuery();                       
                        area.setText("");
                        while(rs.next()){
                            tess= (rs.getInt("NumeroTesserinoSp")); 
                            s1=( rs.getString("Specializzazione"));
                            s2=(rs.getString("Email"));
                            s3=(rs.getString("TelefonoSpecialista"));
                            s4= (rs.getString("CodiceFiscale"));
                            s5=(rs.getString("Nome"));
                            s6= (rs.getString("Cognome"));
                            area.append("Numero tesserino: "+tess+" Specializzazione : "+ s1+"\n"+                                   
                                        " Email: "+s2+"\n"+ " Telefono: "+s3+ "\n"+
                                     "Codice fiscale paziente:"+s4 +"\n"+
                                  "Nome e Cognome: "+s5+" "+s6+"\n");                           
                        }
                    }
                    catch(SQLException so){
                     System.out.println(so.getMessage());   
                     JOptionPane.showMessageDialog(null, "Si e' verificato un'errore durante la ricerca degli specialisti/pazienti");                     
                    }
                }    
                else    
                JOptionPane.showMessageDialog(null, "Si e' verificato un problema durante l'inserimento");
            
            }
        }
    if(s.compareTo("Ins Macchinario")==0){
                       
            p1=(JTextField)p.getComponent(1);//NumeroSerie
            p2=(JTextField)p.getComponent(3);//DataInstallazione
            p3=(JTextField)p.getComponent(5);//Modello           
            p4=(JTextField)p.getComponent(7);//Fornitore
            p5=(JTextField)p.getComponent(9);//Descrizione
            
            s1= p1.getText(); 
            s2= p2.getText(); 
            s3= p3.getText(); 
            s4= p4.getText(); 
            s5= p5.getText(); 
            PreparedStatement pstmt;
            
            try {                               
                String query=
                     ("INSERT INTO MacchinarioDiDiagnostica (NumeroSerie, DataInstallazione, Modello, Fornitore, Descrizione) "
                     + "VALUES(?, ?, ?, ?, ?);"                  
                );                
                pstmt = con.prepareStatement(query);
                pstmt.setString(1,s1); 
                pstmt.setString(2,s2);                                
                pstmt.setString(3,s5);                
                pstmt.setString(4,s3);                                
                pstmt.setString(5,s4);
                pstmt.executeUpdate(); 
                
                JOptionPane.showMessageDialog(null,"Inserimento avvenuto con sucesso");                
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
                if(ex.getErrorCode()==1062){
                    JOptionPane.showMessageDialog(null, "Il macchinario inserito e' già presente nel database");
                    try{ 
                        int NumeroSerie;
                        String query=
                        ("SELECT *"
                                + "FROM MacchinarioDiDiagnostica"                                       
                        );                
                        pstmt = con.prepareStatement(query);
                        ResultSet rs= pstmt.executeQuery();                       
                        area.setText("");
                        while(rs.next()){
                            NumeroSerie= (rs.getInt("NumeroSerie")); 
                            s1=( rs.getString("DataInstallazione"));
                            s2=(rs.getString("Modello"));
                            s3=(rs.getString("Fornitore"));
                            s4= (rs.getString("Descrizione"));
                            area.append(" Numero di serie: "+NumeroSerie+" Data installazione : "+ s1+"\n"+                                   
                                        " Modello: "+s2+"\n"+ " Fornitore: "+s3+ "\n"+
                                     "Descrizione:"+"\n"+s4 +"\n"+
                                  "\n");                           
                        }
                    }
                    catch(SQLException so){
                     System.out.println(so.getMessage());   
                     JOptionPane.showMessageDialog(null, "Si e' verificato un'errore durante la ricerca dei macchinari di diagnostica");                     
                    }
                }   
                
                else
                    JOptionPane.showMessageDialog(null, "Si e' verificato un'errore durante l'inserimento del macchinario di diagnostica");                     
                
            }
        }    
        
    if(s.compareTo("Ins Costituita")==0){
                       
            p1=(JTextField)p.getComponent(1);//DataInizio
            p2=(JTextField)p.getComponent(3);//DataFine
            p3=(JTextField)p.getComponent(5);//CodiceFiscale           
            p4=(JTextField)p.getComponent(7);//NumeroTesserinoSp
            p5=(JTextField)p.getComponent(9);//CodiceFarmaco
            
            s1= p1.getText(); 
            s2= p2.getText(); 
            s3= p3.getText(); 
            s4= p4.getText(); 
            s5= p5.getText(); 
            PreparedStatement pstmt;
            
            try {                               
                String query=
                     ("INSERT INTO Costituita (DataInizio, DataFine, CodiceFiscale, NumeroTesserinoSp,CodiceFarmaco) "
                     + "VALUES(?, ?, ?, ?, ?);"                  
                );                
                pstmt = con.prepareStatement(query);
                pstmt.setString(1,s1); 
                pstmt.setString(2,s2);                                
                pstmt.setString(3,s3);                
                pstmt.setString(4,s4);                                
                pstmt.setString(5,s5);
                pstmt.executeUpdate(); 
                
                JOptionPane.showMessageDialog(null,"Inserimento avvenuto con sucesso");                
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());                           
                if(ex.getErrorCode()==1452){
                    JOptionPane.showMessageDialog(null, "Non è stata trovata nessuna terapia relativa alle informazioni inserite"); 
                    try{ 
                        int tess;
                        String query=
                        ("SELECT * FROM TERAPIA"                                       
                        );                
                        pstmt = con.prepareStatement(query);
                        ResultSet rs= pstmt.executeQuery();                       
                        area.setText("");
                        while(rs.next()){
                            s1=( rs.getString("DataInizio"));
                            s2=(rs.getString("DataFine"));
                            s3=(rs.getString("Malattia"));
                            s4=(rs.getString("CodiceFiscale"));
                            tess= (rs.getInt("NumeroTesserinoSp")); 
                            
                            area.append("DataInizio: "+s1+" Data Fine: "+ s2+
                                            " Malattia: "+s3+"\n"+
                                        "Codice fiscale paziente: "+ s4+ "\n"+
                                        "Numero tesserino specialista: "+ tess + "\n");                           
                        }
                        
                    }
                    catch(SQLException so){
                     JOptionPane.showMessageDialog(null, "Si e' verificato un'errore durante la ricerca delle terapie");                     
                    }
                }    
                else    
                JOptionPane.showMessageDialog(null, "Si e' verificato un problema durante l'inserimento");
            }
        }            
           
} 
    public void getStuff(JPanel p,String s,Connection con,ButtonGroup bg){
        this.bg= bg;
        this.p=p;
        this.s=s;
        this.con= con;
    }
    
    public void getStuff(JPanel p,String s,Connection con, JTextArea area){
        this.area= area;
        this.p=p;
        this.s=s;
        this.con= con;
    }
    
    public void getStuff(JPanel p,String s,Connection con){
        this.p=p;
        this.s=s;
        this.con= con;
    }
    public void removeOlderComponent(JPanel p){
        p.removeAll();
        BoxLayout layout = new BoxLayout(p, BoxLayout.Y_AXIS);        
        p.setLayout(layout);        
        p.revalidate();
        p.repaint();
    }
}
