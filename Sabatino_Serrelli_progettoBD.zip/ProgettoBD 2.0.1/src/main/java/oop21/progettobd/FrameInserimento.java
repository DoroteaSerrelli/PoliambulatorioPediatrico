package oop21.progettobd;

import java.awt.*;
import java.sql.Connection;
import javax.swing.*;
import javax.swing.border.LineBorder;

public class FrameInserimento extends JFrame {
    //setting up the frame to be centered on any pc device
    FrameInserimento(Connection con){ 
    Connection connection;
    connection= con;
    Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
        int screen_width = (int) screen.getWidth();
        int screen_height= (int) screen.getHeight();
        //setting up frame height and frame width
        final int frame_height= 450;
        final int frame_width=  600;
        //JFrame frame= new JFrame();
        this.setSize(frame_width, frame_height);
        
        this.setTitle("Frame di Inserimento");
        //ImageIcon image= new ImageIcon("pagurino.jpg");
        
        //this.setIconImage(image.getImage());
        this.setDefaultCloseOperation(FrameInserimento.DISPOSE_ON_CLOSE);
        
        this.setLocation(screen_width/4, screen_height/7);
        
        //INIZIO SIDEBAR
        this.setLayout(new BorderLayout(5,0));
        JPanel sidebar= new JPanel();
        sidebar.setBackground(Color.LIGHT_GRAY);
        sidebar.setBorder(new LineBorder(new Color(140,242,208),5));
        sidebar.setPreferredSize(new Dimension(150,100));
        sidebar.setLayout(new FlowLayout(FlowLayout.LEFT));        
        //SIDEBAR FINE IMPOSTAZIONI
    
        /////CREAZIONE PULSANTI
        JButton queryIns1= new JButton("Ins Paziente");
        queryIns1.setPreferredSize(new Dimension(125,25));        
        JButton queryIns2= new JButton("Ins Visita");
        queryIns2.setPreferredSize(new Dimension(125,25));
        JButton queryIns3= new JButton("Ins Personale");
        queryIns3.setPreferredSize(new Dimension(125,25));
        JButton queryIns4= new JButton("Ins Specialista");
        queryIns4.setPreferredSize(new Dimension(125,25));
        JButton queryIns5= new JButton("Ins Assistito");
        queryIns5.setPreferredSize(new Dimension(125,25));
        JButton queryIns6= new JButton("Ins Terapia");
        queryIns6.setPreferredSize(new Dimension(125,25));
        JButton queryIns7= new JButton("Ins Collaboratore");
        queryIns7.setPreferredSize(new Dimension(125,25));
        JButton queryIns8= new JButton("Ins Responsabile");
        queryIns8.setPreferredSize(new Dimension(125,25));
        JButton queryIns9= new JButton("Ins Ecografia");
        queryIns9.setPreferredSize(new Dimension(125,25));
        JButton queryIns10= new JButton("Ins Costituita");
        queryIns10.setPreferredSize(new Dimension(125,25));       
        JButton queryIns11= new JButton("Ins Sanificazione");
        queryIns11.setPreferredSize(new Dimension(125,25));           
        JButton queryIns12= new JButton("Ins Macchinario");
        queryIns11.setPreferredSize(new Dimension(125,25));
        
        //Aggiunto perchè non so come gestire la pulizia dei form in modo 
        //Efficiente in modo tale che resetti pulsanti e flag
        JButton pulizia_form= new JButton("Reset Form");
        queryIns10.setPreferredSize(new Dimension(125,25));
        
        //////FINE CREAZIONE PULSANTI
        //GESTIONE DEGLI EVENTI
        AddActionListener2_0 al= new AddActionListener2_0();
        
        //Gruppo Action Listener
        queryIns1.addActionListener(al);
        queryIns2.addActionListener(al);
        queryIns3.addActionListener(al);
        queryIns4.addActionListener(al);
        queryIns5.addActionListener(al);
        queryIns6.addActionListener(al);       
        queryIns7.addActionListener(al); 
        queryIns8.addActionListener(al);
        queryIns9.addActionListener(al);
        queryIns10.addActionListener(al);
        queryIns11.addActionListener(al);
        queryIns12.addActionListener(al);
        
        
        pulizia_form.addActionListener(al);
        //TERMINA QUI -Gruppo Action Listener-
        
        JPanel InputInsertP= new JPanel();       
        al.getStuff(InputInsertP,con);
       
        ///Layout del panello dei form INIZIA QUI
        BoxLayout layout = new BoxLayout(InputInsertP, BoxLayout.Y_AXIS);
        InputInsertP.setLayout(layout);
        InputInsertP.setMaximumSize(new Dimension(800,400));
        add(Box.createRigidArea(new Dimension(50, 0)));
        
        //Layout del panello del form FINISCE QUI
        
        //MAGARI PERMETTE DI GESTIRE LE RIGHE DI QUESTO LAYOUT ç_ç
                      
       //////CATENA DI AGGIUNTA DEI PULSANTI ALLA SIDEBAR
        sidebar.add(queryIns1);
        sidebar.add(queryIns2);
        sidebar.add(queryIns3);
        sidebar.add(queryIns4);
        sidebar.add(queryIns5);
        sidebar.add(queryIns6);
        sidebar.add(queryIns7);
        sidebar.add(queryIns8);
        sidebar.add(queryIns9);
        sidebar.add(queryIns10);
        sidebar.add(queryIns11);  
        sidebar.add(queryIns12);  
        
        sidebar.add(pulizia_form);

        //////TERMINA QUI -CATENA DI AGGIUNTA DEI PULSANTI ALLA SIDEBAR-
        
        this.add(sidebar,BorderLayout.WEST);
        this.add(InputInsertP,BorderLayout.CENTER);
        this.setVisible(true);
       
    }
}
