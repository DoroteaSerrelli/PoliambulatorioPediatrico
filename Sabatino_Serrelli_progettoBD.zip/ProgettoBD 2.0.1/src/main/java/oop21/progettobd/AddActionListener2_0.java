package oop21.progettobd;

import java.sql.Connection;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class AddActionListener2_0 implements ActionListener{
      public JPanel inputPanel;
    Connection con;
    YetAnotherListener ln= new YetAnotherListener();
    ///flag di controllo per verificare se i form sono
    ///visibili o meno rimosse in questa versione del listener perchè
    ///voglio vedere se posso allegerire il programma e ottantamillioni 
    /// di booleane non credo lo rendano per nulla leggero---o inglese che mi fa ridere de più
    /// "I don't think that eight million boolean variables make this thing any ligher whatsoever"
    public int counter_of_forms_displayed= 0;
            
    @Override
    public void actionPerformed(ActionEvent ae) {
        String s= ae.getActionCommand();
        if(s.compareTo("Ins Paziente")==0){ 
           if(counter_of_forms_displayed==1){
            removeOlderComponent(inputPanel);
            counter_of_forms_displayed=0;
           }                      
            if(counter_of_forms_displayed==0){               
            //Dichiarazione di tutto il bordello dei componenti INIZIO   
            JLabel labcf= new JLabel("Codice fiscale:");            
            JTextField cf= new JTextField("");
            JLabel labpadre= new JLabel("Padre:");
            JTextField padre= new JTextField("");   
            JLabel labmadre= new JLabel("Madre:");
            JTextField madre= new JTextField("");
            JLabel labnome= new JLabel("Nome:");
            JTextField nome= new JTextField("");
            JLabel labcognome= new JLabel("Cognome:");
            JTextField cognome= new JTextField("");
            JRadioButton m= new JRadioButton("M");
            JRadioButton f= new JRadioButton("F");            
            JLabel labluogonas= new JLabel("Luogo Nascita:");
            JTextField luogonas= new JTextField("");            
            JLabel labdatanas= new JLabel("Data Nascita: Anno-Mese-Giorno");
            JTextField datanas= new JTextField("");
            ButtonGroup bg= new ButtonGroup();
            bg.add(m);
            bg.add(f);
            JButton confirm= new JButton("Conferma");
            //Dichiarazione di tutto il bordello dei componenti FINE
                       
            Dimension dim_txt_fields= new Dimension(400,20);
            cf.setPreferredSize(dim_txt_fields);
            padre.setPreferredSize(dim_txt_fields);
            madre.setPreferredSize(dim_txt_fields);
            nome.setPreferredSize(dim_txt_fields);
            cognome.setPreferredSize(dim_txt_fields);
            luogonas.setPreferredSize(dim_txt_fields);
            datanas.setPreferredSize(dim_txt_fields);
            
            cf.setMaximumSize(dim_txt_fields);
            padre.setMaximumSize(dim_txt_fields);
            madre.setMaximumSize(dim_txt_fields);
            nome.setMaximumSize(dim_txt_fields);
            cognome.setMaximumSize(dim_txt_fields);       
            luogonas.setMaximumSize(dim_txt_fields);
            datanas.setMaximumSize(dim_txt_fields);       
            
            //Aggiunge tutti i componenti nel panello INIZIO
            inputPanel.add(labcf);
            inputPanel.add(cf);
            inputPanel.add(labpadre);
            inputPanel.add(padre);
            inputPanel.add(labmadre);
            inputPanel.add(madre);
            inputPanel.add(labnome);
            inputPanel.add(nome);
            inputPanel.add(labcognome);
            inputPanel.add(cognome);
            inputPanel.add(m);
            inputPanel.add(f);    
            inputPanel.add(labluogonas);
            inputPanel.add(luogonas);
            inputPanel.add(labdatanas);
            inputPanel.add(datanas);
            inputPanel.add(confirm);
            //Aggiunge tutti i componenti nel panello FINE
            
            counter_of_forms_displayed=1;
            
            inputPanel.revalidate();
            inputPanel.repaint();
                        
            confirm.addActionListener(ln);
            ln.getStuff(inputPanel,s,con,bg);
            }
        }
        if(s.compareTo("Ins Visita")==0){
            if(counter_of_forms_displayed==1){                
              removeOlderComponent(inputPanel);  
              counter_of_forms_displayed=0;
            }            
            if(counter_of_forms_displayed==0){
             //Dichiarazione di tutto il bordello dei componenti INIZIO   
             
            JLabel labora= new JLabel("Ora: Ora:Minuti:Secondi");            
            JTextField ora= new JTextField("");
            JLabel labtipo= new JLabel("Tipo:");
            JTextField tipo= new JTextField("");   
            JLabel labdatav= new JLabel("DataV Anno-Mese-Giorno:");
            JTextField datav= new JTextField("");
            JLabel labcf= new JLabel("Codice fiscale paziente:");
            JTextField cf= new JTextField("");
            JLabel labts= new JLabel("Numero tesserino specialista:");
            JTextField tess= new JTextField("");
            JTextArea area= new JTextArea("");
            JButton confirm= new JButton("Conferma");
            //Dichiarazione di tutto il bordello dei componenti FINE
                       
            Dimension dim_txt_fields= new Dimension(400,20);
            ora.setPreferredSize(dim_txt_fields);
            tipo.setPreferredSize(dim_txt_fields);
            datav.setPreferredSize(dim_txt_fields);
            cf.setPreferredSize(dim_txt_fields);
            tess.setPreferredSize(dim_txt_fields);
            
            ora.setMaximumSize(dim_txt_fields);
            tipo.setMaximumSize(dim_txt_fields);
            datav.setMaximumSize(dim_txt_fields);
            cf.setMaximumSize(dim_txt_fields);
            tess.setMaximumSize(dim_txt_fields);     
            
            JScrollPane something= new JScrollPane(area);
            something.setAlignmentX(0.0f);
            something.setPreferredSize(new Dimension(450, 110));                    
            area.setEditable(false);            
            area.setMaximumSize(new Dimension(700,400));           
                       
            //Aggiunge tutti i componenti nel panello INIZIO
            inputPanel.add(labora);
            inputPanel.add(ora);
            inputPanel.add(labtipo);
            inputPanel.add(tipo);
            inputPanel.add(labdatav);
            inputPanel.add(datav);
            inputPanel.add(labcf);
            inputPanel.add(cf);
            inputPanel.add(labts);
            inputPanel.add(tess);           
            inputPanel.add(confirm);
           
            inputPanel.add(something,BorderLayout.CENTER);           
            //Aggiunge tutti i componenti nel panello FINE
            
            counter_of_forms_displayed=1;
            
            inputPanel.revalidate();
            inputPanel.repaint();
                        
            confirm.addActionListener(ln);
            ln.getStuff(inputPanel,s,con,area);
            }   
        }    
            if(s.compareTo("Ins Personale")==0){ 
                if(counter_of_forms_displayed==1){
                    removeOlderComponent(inputPanel);
                    counter_of_forms_displayed=0;
                }
                if(counter_of_forms_displayed==0){               
                //Dichiarazione di tutto il bordello dei componenti INIZIO   
                JLabel labtess= new JLabel("Tesserino del personale:");            
                JTextField tess= new JTextField("");
                JLabel labnome= new JLabel("Nome:");
                JTextField nome= new JTextField("");   
                JLabel labcognome= new JLabel("Cognome:");
                JTextField cognome= new JTextField("");
                JLabel labeta= new JLabel("Età (compresa tra i 35 e i 66 anni):");
                JTextField eta= new JTextField("");            
                JLabel labtipoco= new JLabel("Tipologia di contratto lavorativo (Parziale o Indeterminato)");
                JTextField tipoco= new JTextField("");
                JButton confirm= new JButton("Conferma");
                //Dichiarazione di tutto il bordello dei componenti FINE
                       
                Dimension dim_txt_fields= new Dimension(400,20);
                tess.setPreferredSize(dim_txt_fields);
                nome.setPreferredSize(dim_txt_fields);
                cognome.setPreferredSize(dim_txt_fields);
                eta.setPreferredSize(dim_txt_fields);
                tipoco.setPreferredSize(dim_txt_fields);
            
                tess.setMaximumSize(dim_txt_fields);
                nome.setMaximumSize(dim_txt_fields);
                cognome.setMaximumSize(dim_txt_fields);       
                eta.setMaximumSize(dim_txt_fields);
                tipoco.setMaximumSize(dim_txt_fields);                   
                //Aggiunge tutti i componenti nel panello INIZIO
                inputPanel.add(labtess);
                inputPanel.add(tess);
                inputPanel.add(labnome);
                inputPanel.add(nome);
                inputPanel.add(labcognome);
                inputPanel.add(cognome);
                inputPanel.add(labeta);
                inputPanel.add(eta);
                inputPanel.add(labtipoco);
                inputPanel.add(tipoco);
                inputPanel.add(confirm);
                //Aggiunge tutti i componenti nel panello FINE            
                counter_of_forms_displayed=1;
            
                inputPanel.revalidate();
                inputPanel.repaint();
                        
                confirm.addActionListener(ln);
                ln.getStuff(inputPanel,s,con);
            }
        }
        if(s.compareTo("Ins Specialista")==0){ 
            if(counter_of_forms_displayed==1){
                removeOlderComponent(inputPanel);
                counter_of_forms_displayed=0;
            }
            
            if(counter_of_forms_displayed==0){               
            //Dichiarazione di tutto il bordello dei componenti INIZIO   
            JLabel labtess= new JLabel("Tesserino dello specialista:");            
            JTextField tess= new JTextField("");
            JLabel labspec= new JLabel("Specializzazione:");
            JTextField spec= new JTextField("");   
            JLabel labannis= new JLabel("Anni di servizio:");
            JTextField annis= new JTextField("");
            JLabel labemail= new JLabel("Email nella forma (%.%@poliambulatoriopediatrico.it):");
            JTextField email= new JTextField("");            
            JLabel labtel= new JLabel("Telefono nella forma('+39 ___ ___ ____' al posto dei ___ inserire numero");
            JTextField tel= new JTextField("");            
            JLabel labcodamb= new JLabel("Codice dell'ambulatorio:");
            JTextField codamb= new JTextField("");
            JTextArea area= new JTextArea("");
            JButton confirm= new JButton("Conferma");
            //Dichiarazione di tutto il bordello dei componenti FINE
                       
            Dimension dim_txt_fields= new Dimension(400,20);
            tess.setPreferredSize(dim_txt_fields);
            spec.setPreferredSize(dim_txt_fields);
            annis.setPreferredSize(dim_txt_fields);
            email.setPreferredSize(dim_txt_fields);
            tel.setPreferredSize(dim_txt_fields);
            codamb.setPreferredSize(dim_txt_fields);
            
            tess.setMaximumSize(dim_txt_fields);
            spec.setMaximumSize(dim_txt_fields);
            annis.setMaximumSize(dim_txt_fields);       
            email.setMaximumSize(dim_txt_fields);
            tel.setMaximumSize(dim_txt_fields);       
            codamb.setMaximumSize(dim_txt_fields);       
            
            JScrollPane something= new JScrollPane(area);
            something.setAlignmentX(0.0f);
            something.setPreferredSize(new Dimension(450, 110));                    
            area.setEditable(false);         
            area.setMaximumSize(new Dimension(700,400)); 
            
            //Aggiunge tutti i componenti nel panello INIZIO
            inputPanel.add(labtess);
            inputPanel.add(tess);
            inputPanel.add(labspec);
            inputPanel.add(spec);
            inputPanel.add(labannis);
            inputPanel.add(annis);
            inputPanel.add(labemail);
            inputPanel.add(email);
            inputPanel.add(labtel);
            inputPanel.add(tel);
            inputPanel.add(labcodamb);
            inputPanel.add(codamb);
            inputPanel.add(confirm);
            
            inputPanel.add(something,BorderLayout.CENTER);
            //Aggiunge tutti i componenti nel panello FINE
            
            counter_of_forms_displayed=1;
            
            inputPanel.revalidate();
            inputPanel.repaint();
                        
            confirm.addActionListener(ln);
            ln.getStuff(inputPanel,s,con,area);
            }
        }
        
        
        if(s.compareTo("Ins Assistito")==0){ 
            if(counter_of_forms_displayed==1){
                removeOlderComponent(inputPanel);
                counter_of_forms_displayed=0;
            }
            
            if(counter_of_forms_displayed==0){               
            //Dichiarazione di tutto il bordello dei componenti INIZIO   
            JLabel labtess= new JLabel("Numero tesserino dello specialista:");            
            JTextField tess= new JTextField("");
            JLabel labtessco= new JLabel("Numero tesserino del collaboratore:");
            JTextField tessco= new JTextField("");            
            JLabel labnumore= new JLabel("Numero medio di ore di collaborazione:");
            JTextField numore= new JTextField("");   
            JLabel labanno= new JLabel("Anno inizio collaborazione:");
            JTextField anno= new JTextField("");   
            
            JButton confirm= new JButton("Conferma");
            //Dichiarazione di tutto il bordello dei componenti FINE
                       
            Dimension dim_txt_fields= new Dimension(150,20);
            tess.setPreferredSize(dim_txt_fields);
            tessco.setPreferredSize(dim_txt_fields); 
            numore.setPreferredSize(dim_txt_fields);
            anno.setPreferredSize(dim_txt_fields);
            
            tess.setMaximumSize(dim_txt_fields);
            tessco.setMaximumSize(dim_txt_fields);  
            numore.setMaximumSize(dim_txt_fields);
            anno.setMaximumSize(dim_txt_fields);             
            
            //Aggiunge tutti i componenti nel panello INIZIO
            inputPanel.add(labtess);
            inputPanel.add(tess);
            inputPanel.add(labtessco);
            inputPanel.add(tessco);
            inputPanel.add(labnumore);
            inputPanel.add(numore);
            inputPanel.add(labanno);
            inputPanel.add(anno);
            inputPanel.add(confirm);
            //Aggiunge tutti i componenti nel panello FINE
            
            counter_of_forms_displayed=1;
            
            inputPanel.revalidate();
            inputPanel.repaint();
                        
            confirm.addActionListener(ln);
            ln.getStuff(inputPanel,s,con);
            }
        }
        
        if(s.compareTo("Ins Terapia")==0){ 
            if(counter_of_forms_displayed==1){
                removeOlderComponent(inputPanel);
                counter_of_forms_displayed=0;
            }
            
            if(counter_of_forms_displayed==0){               
            //Dichiarazione di tutto il bordello dei componenti INIZIO   
            JLabel labdatain= new JLabel("Data inizio terapia nel formato Anno-Mese-Giorno:");            
            JTextField datain= new JTextField("");
            JLabel labdataf= new JLabel("Data fine terapia nel formato Anno-Mese-Giorno:");
            JTextField dataf= new JTextField("");
            JLabel labmalattia= new JLabel("Malattia:");
            JTextField malattia= new JTextField("");   
            JLabel labcf= new JLabel("Codice fiscale del paziente:");
            JTextField cf= new JTextField("");   
            JLabel labnumtess= new JLabel("Numero tesserino dello specialista:");
            JTextField numtess= new JTextField("");   
            JTextArea area= new JTextArea("");
            JButton confirm= new JButton("Conferma");
            //Dichiarazione di tutto il bordello dei componenti FINE
                       
            Dimension dim_txt_fields= new Dimension(260,20);
            datain.setPreferredSize(dim_txt_fields);
            dataf.setPreferredSize(dim_txt_fields);            
            malattia.setPreferredSize(dim_txt_fields);            
            cf.setPreferredSize(dim_txt_fields);            
            numtess.setPreferredSize(dim_txt_fields);            
            
            datain.setMaximumSize(dim_txt_fields);
            dataf.setMaximumSize(dim_txt_fields);
            malattia.setMaximumSize(dim_txt_fields);            
            cf.setMaximumSize(dim_txt_fields);
            numtess.setMaximumSize(dim_txt_fields);            
            
            JScrollPane something= new JScrollPane(area);
            something.setAlignmentX(0.0f);
            something.setPreferredSize(new Dimension(450, 110));                    
            area.setEditable(false);         
            area.setMaximumSize(new Dimension(700,400)); 
            
            //Aggiunge tutti i componenti nel panello INIZIO
            inputPanel.add(labdatain);
            inputPanel.add(datain);
            inputPanel.add(labdataf);
            inputPanel.add(dataf);
            inputPanel.add(labmalattia);
            inputPanel.add(malattia);
            inputPanel.add(labcf);
            inputPanel.add(cf);
            inputPanel.add(labnumtess);
            inputPanel.add(numtess);
            inputPanel.add(confirm);
            
            inputPanel.add(something,BorderLayout.CENTER);
            //Aggiunge tutti i componenti nel panello FINE
            
            counter_of_forms_displayed=1;
            
            inputPanel.revalidate();
            inputPanel.repaint();
                        
            confirm.addActionListener(ln);
            ln.getStuff(inputPanel,s,con,area);
            }
        }
    
    if(s.compareTo("Ins Collaboratore")==0){ 
            if(counter_of_forms_displayed==1){
                removeOlderComponent(inputPanel);
                counter_of_forms_displayed=0;
            }
            
            
            if(counter_of_forms_displayed==0){               
            //Dichiarazione di tutto il bordello dei componenti INIZIO   
            JLabel labtessco= new JLabel("Numero tesserino del collaboratore:");            
            JTextField tessco= new JTextField("");
            JLabel labnum= new JLabel("Numero dei macchinari gestiti dal collaboratore:");
            JTextField num= new JTextField("");
            JLabel labspec= new JLabel("Specializzazione:");
            JTextField spec= new JTextField("");   
            
            JButton confirm= new JButton("Conferma");
            //Dichiarazione di tutto il bordello dei componenti FINE
                       
            Dimension dim_txt_fields= new Dimension(260,20);
            tessco.setPreferredSize(dim_txt_fields);
            num.setPreferredSize(dim_txt_fields);            
            spec.setPreferredSize(dim_txt_fields);            
            
            tessco.setMaximumSize(dim_txt_fields);
            num.setMaximumSize(dim_txt_fields);
            spec.setMaximumSize(dim_txt_fields);            
            
            //Aggiunge tutti i componenti nel panello INIZIO
            inputPanel.add(labtessco);
            inputPanel.add(tessco);
            inputPanel.add(labnum);
            inputPanel.add(num);
            inputPanel.add(labspec);
            inputPanel.add(spec);
            
            inputPanel.add(confirm);
            //Aggiunge tutti i componenti nel panello FINE
            
            counter_of_forms_displayed=1;
            
            inputPanel.revalidate();
            inputPanel.repaint();
                        
            confirm.addActionListener(ln);
            ln.getStuff(inputPanel,s,con);
            }
        }    
    
    if(s.compareTo("Ins Responsabile")==0){ 
            if(counter_of_forms_displayed==1){
                removeOlderComponent(inputPanel);
                counter_of_forms_displayed=0;
            }
            
            
            if(counter_of_forms_displayed==0){                               
            //Dichiarazione di tutto il bordello dei componenti INIZIO   
            JLabel labtessco= new JLabel("Numero tesserino del collaboratore:");            
            JTextField tessco= new JTextField("");
            JLabel labnum= new JLabel("Numero serie del macchinario:");
            JTextField num= new JTextField("");
 
            //////Se rimuovere area per motivi estetici rimuovere questo
            //JTextArea area= new JTextArea("");
            ////////////////////////////////////////////////////////////
            
            JButton confirm= new JButton("Conferma");
            //Dichiarazione di tutto il bordello dei componenti FINE
                       
            Dimension dim_txt_fields= new Dimension(260,20);
            tessco.setPreferredSize(dim_txt_fields);
            num.setPreferredSize(dim_txt_fields);            
            
            tessco.setMaximumSize(dim_txt_fields);
            num.setMaximumSize(dim_txt_fields);
            
            /*/////Scroller + Area /////////////////////////////
            JScrollPane something= new JScrollPane(area);
            something.setAlignmentX(0.0f);
            something.setPreferredSize(new Dimension(450, 110));                    
            area.setEditable(false);         
            area.setMaximumSize(new Dimension(700,400)); 
            //////////////////////////////////////////////////*/
            
            //Aggiunge tutti i componenti nel panello INIZIO
            inputPanel.add(labtessco);
            inputPanel.add(tessco);
            inputPanel.add(labnum);
            inputPanel.add(num);
            inputPanel.add(confirm);
            
            ///Aggiunta scroller/////////////////////////////////
           // inputPanel.add(something,BorderLayout.CENTER);
           /////////////////////////////////////////////////////////
          
            //Aggiunge tutti i componenti nel panello FINE
            
            counter_of_forms_displayed=1;
            
            inputPanel.revalidate();
            inputPanel.repaint();
                        
            confirm.addActionListener(ln);
            
            ln.getStuff(inputPanel, s, con);           
            //ln.getStuff(inputPanel,s,con,area); Versione con TextArea
            
            }
        }
    
    if(s.compareTo("Ins Ecografia")==0){ 
        if(counter_of_forms_displayed==1){
          removeOlderComponent(inputPanel);
          counter_of_forms_displayed=0;
        }            
        if(counter_of_forms_displayed==0){                               
            //Dichiarazione di tutto il bordello dei componenti INIZIO              
            JLabel labcodeco= new JLabel("Codice dell'ecografia inserita:");            
            JTextField codeco= new JTextField("");
            JLabel labnomeco= new JLabel("Nome dell'ecografia:");
            JTextField nomeco= new JTextField("");
            JLabel labcf= new JLabel("Inserire il codice fiscale del paziente:");
            JTextField cf= new JTextField("");   
            JLabel labtess= new JLabel("Inserire il numero del tesserino dello specialista:");
            JTextField tess= new JTextField("");   
            JLabel labdesc= new JLabel("Inserire la descrizione:");
            JTextField desc= new JTextField("");             
            JTextArea area= new JTextArea("");
            JButton confirm= new JButton("Conferma");
            //Dichiarazione di tutto il bordello dei componenti FINE
                       
            Dimension dim_txt_fields= new Dimension(400,20);
            codeco.setPreferredSize(dim_txt_fields);
            nomeco.setPreferredSize(dim_txt_fields);            
            cf.setPreferredSize(dim_txt_fields); 
            tess.setPreferredSize(dim_txt_fields);            
            desc.setPreferredSize(dim_txt_fields);            
                       
            codeco.setMaximumSize(dim_txt_fields);
            nomeco.setMaximumSize(dim_txt_fields);
            cf.setMaximumSize(dim_txt_fields); 
            tess.setMaximumSize(dim_txt_fields);
            desc.setMaximumSize(dim_txt_fields);            
            
            
            JScrollPane something= new JScrollPane(area);
            something.setAlignmentX(0.0f);
            something.setPreferredSize(new Dimension(450, 110));                    
            area.setEditable(false);            
            area.setMaximumSize(new Dimension(700,400)); 
            
            //Aggiunge tutti i componenti nel panello INIZIO
            inputPanel.add(labcodeco);
            inputPanel.add(codeco);
            inputPanel.add(labnomeco);
            inputPanel.add(nomeco);
            inputPanel.add(labcf);
            inputPanel.add(cf);
            inputPanel.add(labtess);
            inputPanel.add(tess);           
            inputPanel.add(labdesc);
            inputPanel.add(desc);
            inputPanel.add(confirm);
            
            inputPanel.add(something,BorderLayout.CENTER);
          
            //Aggiunge tutti i componenti nel panello FINE
            counter_of_forms_displayed=1;
            
            inputPanel.revalidate();
            inputPanel.repaint();
                        
            confirm.addActionListener(ln);
            ln.getStuff(inputPanel,s,con,area);
        }
    }     
    if(s.compareTo("Ins Macchinario")==0){ 
        if(counter_of_forms_displayed==1){
          removeOlderComponent(inputPanel);
          counter_of_forms_displayed=0;
        }            
        if(counter_of_forms_displayed==0){                               
            //Dichiarazione di tutto il bordello dei componenti INIZIO              
            JLabel labnumserie= new JLabel("Numero serie del macchinario:");            
            JTextField numserie= new JTextField("");
            JLabel labdataist= new JLabel("Data installazione nel formato Anno-Mese-Giorno:");
            JTextField dataist= new JTextField("");
            JLabel labmodello= new JLabel("Inserire il modello del macchinario di diagnostica:");
            JTextField modello= new JTextField("");   
            JLabel labfornitore= new JLabel("Inserire il fornitore:");
            JTextField fornitore= new JTextField("");   
            JLabel labdesc= new JLabel("Inserire la descrizione:");
            JTextField desc= new JTextField("");             
            JTextArea area= new JTextArea("");
            JButton confirm= new JButton("Conferma");
            //Dichiarazione di tutto il bordello dei componenti FINE
                       
            Dimension dim_txt_fields= new Dimension(400,20);
            numserie.setPreferredSize(dim_txt_fields);
            dataist.setPreferredSize(dim_txt_fields);            
            modello.setPreferredSize(dim_txt_fields); 
            fornitore.setPreferredSize(dim_txt_fields);            
            desc.setPreferredSize(dim_txt_fields);            
                       
            numserie.setMaximumSize(dim_txt_fields);
            dataist.setMaximumSize(dim_txt_fields);
            modello.setMaximumSize(dim_txt_fields); 
            fornitore.setMaximumSize(dim_txt_fields);
            desc.setMaximumSize(dim_txt_fields);            
           
            JScrollPane something= new JScrollPane(area);
            something.setAlignmentX(0.0f);
            something.setPreferredSize(new Dimension(450, 110));                    
            area.setEditable(false);            
            area.setMaximumSize(new Dimension(700,400)); 
           
            
            //Aggiunge tutti i componenti nel panello INIZIO
            inputPanel.add(labnumserie);
            inputPanel.add(numserie);
            inputPanel.add(labdataist);
            inputPanel.add(dataist);
            inputPanel.add(labmodello);
            inputPanel.add(modello);
            inputPanel.add(labfornitore);
            inputPanel.add(fornitore);           
            inputPanel.add(labdesc);
            inputPanel.add(desc);
            inputPanel.add(confirm);
           
            inputPanel.add(something,BorderLayout.CENTER);
            
            //Aggiunge tutti i componenti nel panello FINE
            counter_of_forms_displayed=1;
            
            inputPanel.revalidate();
            inputPanel.repaint();
                        
            confirm.addActionListener(ln);
            ln.getStuff(inputPanel,s,con,area);
        }
    }     
    
    if(s.compareTo("Ins Costituita")==0){ 
        if(counter_of_forms_displayed==1){
          removeOlderComponent(inputPanel);
          counter_of_forms_displayed=0;
        }            
        if(counter_of_forms_displayed==0){      
            
            //Dichiarazione di tutto il bordello dei componenti INIZIO              
            JLabel labdatain= new JLabel("Data inizio della terapia nel formato(anno-mese-giorno):");            
            JTextField datain= new JTextField("");
            JLabel labdataf= new JLabel("Data fine della terapia nel formato(anno-mese-giorno):");
            JTextField dataf= new JTextField("");
            JLabel labcf= new JLabel("Inserire il codice fiscale del paziente:");
            JTextField cf= new JTextField("");   
            JLabel labtess= new JLabel("Inserire il numero del tesserino dello specialista:");
            JTextField tess= new JTextField("");   
            JLabel labcodf= new JLabel("Inserire il codice del farmaco prescritto:");
            JTextField codf= new JTextField("");             
            JTextArea area= new JTextArea("");
            JButton confirm= new JButton("Conferma");
            //Dichiarazione di tutto il bordello dei componenti FINE
                       
            Dimension dim_txt_fields= new Dimension(400,20);
            datain.setPreferredSize(dim_txt_fields);
            dataf.setPreferredSize(dim_txt_fields);             
            cf.setPreferredSize(dim_txt_fields); 
            tess.setPreferredSize(dim_txt_fields);            
            codf.setPreferredSize(dim_txt_fields);            
                                  
            datain.setMaximumSize(dim_txt_fields);
            dataf.setMaximumSize(dim_txt_fields);
            cf.setMaximumSize(dim_txt_fields); 
            tess.setMaximumSize(dim_txt_fields);
            codf.setMaximumSize(dim_txt_fields);            
            
            JScrollPane something= new JScrollPane(area);
            something.setAlignmentX(0.0f);
            something.setPreferredSize(new Dimension(450, 110));                    
            area.setEditable(false);            
            area.setMaximumSize(new Dimension(700,400));           
            
            //Aggiunge tutti i componenti nel panello INIZIO
            inputPanel.add(labdatain);
            inputPanel.add(datain);
            inputPanel.add(labdataf);
            inputPanel.add(dataf);
            inputPanel.add(labcf);
            inputPanel.add(cf);
            inputPanel.add(labtess);
            inputPanel.add(tess);           
            inputPanel.add(labcodf);
            inputPanel.add(codf);            
            inputPanel.add(confirm);
         
            
            inputPanel.add(something,BorderLayout.CENTER);
           // inputPanel.add(area);
            
            //Aggiunge tutti i componenti nel panello FINE
            counter_of_forms_displayed=1;
            
            inputPanel.revalidate();
            inputPanel.repaint();
                        
            confirm.addActionListener(ln);
            ln.getStuff(inputPanel,s,con,area);
        }
    }
    if(s.compareTo("Ins Sanificazione")==0){ 
        if(counter_of_forms_displayed==1){
          removeOlderComponent(inputPanel);
          counter_of_forms_displayed=0;
        }            
        if(counter_of_forms_displayed==0){                               
            //Dichiarazione di tutto il bordello dei componenti INIZIO              
            JLabel labcodamb= new JLabel("Codice dell'ambulatorio sanificato:");            
            JTextField codamb= new JTextField("");
            JLabel labiva= new JLabel("Partita IVA dell'ente di sanificazione:");
            JTextField iva= new JTextField("");
            JLabel laborario= new JLabel("Inserire orario sanificazione nel formato Ore:Minuti:Secondi :");
            JTextField orario= new JTextField("");   
            JLabel labdata= new JLabel("Inserire data sanificazione nel formato Anno-Mese-Giorno :");
            JTextField data= new JTextField("");   
            JTextArea area= new JTextArea("");
            JButton confirm= new JButton("Conferma");
            //Dichiarazione di tutto il bordello dei componenti FINE
                       
            Dimension dim_txt_fields= new Dimension(400,20);
            codamb.setPreferredSize(dim_txt_fields);
            iva.setPreferredSize(dim_txt_fields);            
            orario.setPreferredSize(dim_txt_fields); 
            data.setPreferredSize(dim_txt_fields);            
                       
            codamb.setMaximumSize(dim_txt_fields);
            iva.setMaximumSize(dim_txt_fields);
            orario.setMaximumSize(dim_txt_fields); 
            data.setMaximumSize(dim_txt_fields);
            
            
            JScrollPane something= new JScrollPane(area);
            something.setAlignmentX(0.0f);
            something.setPreferredSize(new Dimension(450, 110));                    
            area.setEditable(false);            
            area.setMaximumSize(new Dimension(700,400)); 
            
            //Aggiunge tutti i componenti nel panello INIZIO
            inputPanel.add(labcodamb);
            inputPanel.add(codamb);
            inputPanel.add(labiva);
            inputPanel.add(iva);
            inputPanel.add(laborario);
            inputPanel.add(orario);
            inputPanel.add(labdata);
            inputPanel.add(data);           
            inputPanel.add(confirm);
            
            inputPanel.add(something,BorderLayout.CENTER);
          
            //Aggiunge tutti i componenti nel panello FINE
            counter_of_forms_displayed=1;
            
            inputPanel.revalidate();
            inputPanel.repaint();
                        
            confirm.addActionListener(ln);
            ln.getStuff(inputPanel,s,con,area);
        }
    }
    if(s.compareTo("Reset Form")==0){
        counter_of_forms_displayed=0;
        removeOlderComponent(inputPanel);
        
    }
}    
    public void getStuff(JPanel inputP,Connection con){
        this.inputPanel= inputP;
        this.con= con;
    }
    public void removeOlderComponent(JPanel p){
        p.removeAll();
        BoxLayout layout = new BoxLayout(p, BoxLayout.Y_AXIS);        
        p.setLayout(layout);        
        p.revalidate();
        p.repaint();
    }
    
}

