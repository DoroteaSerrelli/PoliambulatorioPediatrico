package oop21.progettobd;
import java.awt.*;
import java.sql.Connection;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.border.LineBorder;

public class MyFrame extends JFrame {
    //setting up the frame to be centered on any pc device
    MyFrame(Connection con){ 
    Connection connection;
    connection= con;
    Dimension screen = Toolkit.getDefaultToolkit().getScreenSize();
        int screen_width = (int) screen.getWidth();
        int screen_height= (int) screen.getHeight();
        //setting up frame height and frame width
        final int frame_height= 600;
        final int frame_width=  800;
        //JFrame frame= new JFrame();
        this.setSize(frame_width, frame_height);
        this.setTitle("Poliambulatorio Pediatrico");
        //ImageIcon image= new ImageIcon("pagurino.jpg");
        
        //this.setIconImage(image.getImage());
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        this.setLocation(screen_width/4, screen_height/7);
        
        //INIZIO SIDEBAR
        this.setLayout(new BorderLayout(5,0));
        JPanel sidebar= new JPanel();
        sidebar.setBackground(Color.LIGHT_GRAY);
        sidebar.setBorder(new LineBorder(Color.BLUE,5));
        sidebar.setPreferredSize(new Dimension(150,100));
        sidebar.setLayout(new FlowLayout(FlowLayout.LEFT));        
        //SIDEBAR FINE IMPOSTAZIONI
    
        /////CREAZIONE PULSANTI
        JButton queryIns= new JButton("Query Inserimento");
        queryIns.setPreferredSize(new Dimension(125,25));        
        JButton query1= new JButton("Query 1");
        query1.setPreferredSize(new Dimension(125,25));
        JButton query2= new JButton("Query 2");
        query2.setPreferredSize(new Dimension(125,25));
        JButton query3= new JButton("Query 3");
        query3.setPreferredSize(new Dimension(125,25));
        JButton query4= new JButton("Query 4");
        query4.setPreferredSize(new Dimension(125,25));
        JButton query5= new JButton("Query 5");
        query5.setPreferredSize(new Dimension(125,25));
        JButton query6= new JButton("Query 6");
        query6.setPreferredSize(new Dimension(125,25));
        JButton query7= new JButton("Query 7");
        query7.setPreferredSize(new Dimension(125,25));
        JButton query8= new JButton("Query 8");
        query8.setPreferredSize(new Dimension(125,25));
        JButton query9= new JButton("Query 9");
        query9.setPreferredSize(new Dimension(125,25));
        JButton query10= new JButton("Query 10");
        query10.setPreferredSize(new Dimension(125,25));
        
        //////FINE CREAZIONE PULSANTI
        //GESTIONE DEGLI EVENTI
        AddMouseListenerNew ms= new AddMouseListenerNew();
        
        //Gruppo Action Listener
        queryIns.addActionListener(ms);
        query1.addActionListener(ms);
        query2.addActionListener(ms);
        query3.addActionListener(ms);
        query4.addActionListener(ms);
        query5.addActionListener(ms);
        query6.addActionListener(ms);
        query7.addActionListener(ms);
        query8.addActionListener(ms);
        query9.addActionListener(ms);
        query10.addActionListener(ms);
        //TERMINA QUI -Gruppo Action Listener-
        
        JPanel showResultp= new JPanel();
        JTextArea txtArea= new JTextArea();
        JScrollPane scroll= new JScrollPane(txtArea);
        //CON SETSIZE LA TEXT AREA SI ADATTA ALL'OUTPUT DEL TESTO GENERATO
        //CON SETPREFERREDSIZE LA DIMENSIONE RIMANE COSTANTE
      //  txtArea.setPreferredSize(new Dimension(600,600));
        scroll.setPreferredSize(new Dimension(600,400));
      
        txtArea.setLineWrap(true);
        txtArea.setEditable(false);
        txtArea.setWrapStyleWord(true);
        scroll.setVerticalScrollBarPolicy ( ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS );
        
        //txtArea.setSize(500,500);
        showResultp.setLayout(new FlowLayout(FlowLayout.CENTER));
        showResultp.add(scroll);
        
        ms.getStuff(sidebar, con,showResultp,txtArea); 
        
        //////CATENA DI AGGIUNTA DEI PULSANTI ALLA SIDEBAR
        sidebar.add(queryIns);
        sidebar.add(query1);
        sidebar.add(query2);
        sidebar.add(query3);
        sidebar.add(query4);
        sidebar.add(query5);
        sidebar.add(query6);
        sidebar.add(query7);
        sidebar.add(query8);
        sidebar.add(query9);
        sidebar.add(query10);
        //////TERMINA QUI -CATENA DI AGGIUNTA DEI PULSANTI ALLA SIDEBAR-
        
        this.add(sidebar,BorderLayout.WEST);
        this.add(showResultp,BorderLayout.CENTER);
        this.setVisible(true);
       
    }
}
